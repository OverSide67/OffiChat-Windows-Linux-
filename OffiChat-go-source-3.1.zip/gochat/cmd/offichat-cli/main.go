// offichat-cli — консольный клиент для проверки связи с Android-версией OffiChat.
//
//	go run ./cmd/offichat-cli host              ждать подключения на порту 5000
//	go run ./cmd/offichat-cli connect IP        подключиться к телефону или ПК
//
// Строки, которые вы вводите, уходят собеседнику. /edit ID текст, /del ID, /quit — команды.
package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"time"

	"offichat/internal/chat"
)

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	nick := os.Getenv("OFFICHAT_NICK")
	if nick == "" {
		nick = "pc-cli"
	}
	c := chat.New(func() string { return nick })

	switch os.Args[1] {
	case "host":
		if err := c.Host(chat.DefaultPort); err != nil {
			fmt.Fprintln(os.Stderr, "не удалось открыть порт:", err)
			os.Exit(1)
		}
	case "connect":
		if len(os.Args) < 3 {
			usage()
		}
		c.Connect(os.Args[2], chat.DefaultPort)
	default:
		usage()
	}

	go printEvents(c)
	readInput(c)
}

func usage() {
	fmt.Println("использование:")
	fmt.Println("  offichat-cli host           ждать подключения (порт 5000)")
	fmt.Println("  offichat-cli connect IP     подключиться к IP")
	fmt.Println("в чате: текст — отправить, /edit ID текст, /del ID, /quit — выйти")
	os.Exit(2)
}

// printEvents выводит входящее и статусы. Идентификаторы показываются, чтобы их можно было править.
func printEvents(c *chat.Conn) {
	for e := range c.Events() {
		switch e.Kind {
		case "state":
			switch e.State {
			case "waiting":
				fmt.Printf("[ожидание] порт %d. Ваш IP: %s\n", e.Port, localIPs())
			case "connecting":
				fmt.Printf("[подключение] %s...\n", e.Reason)
			case "connected":
				fmt.Printf("[подключено] %s\n", e.Reason)
			case "idle":
				fmt.Printf("[нет связи] %s\n", e.Reason)
			}
		case "nick":
			fmt.Printf("[собеседник] %s\n", e.Nick)
		case "message":
			if e.MID != "" {
				fmt.Printf("← %s  (id %s): %s\n", c.PeerNick(), e.MID, e.Text)
			} else {
				fmt.Printf("← %s: %s\n", c.PeerNick(), e.Text)
			}
			c.MarkRead(e.MID)
		case "local_message":
			fmt.Printf("→ (id %s): %s\n", e.MID, e.Text)
		case "status":
			fmt.Printf("  [%s] %s\n", e.MID, statusText(e.Status))
		case "edit":
			fmt.Printf("✎ %s изменил (id %s): %s\n", c.PeerNick(), e.MID, e.Text)
		case "delete":
			fmt.Printf("✕ %s удалил (id %s)\n", c.PeerNick(), e.MID)
		case "typing":
			if e.On {
				fmt.Println("  … печатает")
			}
		case "note":
			fmt.Println("[заметка]", e.Text)
		}
	}
}

func statusText(s string) string {
	switch s {
	case "delivered":
		return "✓✓ доставлено"
	case "read":
		return "✓✓ прочитано"
	case "fail":
		return "! не отправлено"
	}
	return s
}

func readInput(c *chat.Conn) {
	in := bufio.NewScanner(os.Stdin)
	for in.Scan() {
		line := strings.TrimSpace(in.Text())
		switch {
		case line == "":
		case line == "/quit":
			c.Close()
			time.Sleep(200 * time.Millisecond)
			return
		case strings.HasPrefix(line, "/edit "):
			parts := strings.SplitN(line, " ", 3)
			if len(parts) < 3 {
				fmt.Println("формат: /edit ID новый текст")
				continue
			}
			if !c.Edit(parts[1], parts[2]) {
				fmt.Println("нет соединения")
			}
		case strings.HasPrefix(line, "/del "):
			id := strings.TrimSpace(strings.TrimPrefix(line, "/del "))
			if !c.Delete(id) {
				fmt.Println("нет соединения")
			}
		default:
			if _, ok := c.SendText(line); !ok {
				fmt.Println("нет соединения: сначала host или connect")
			}
		}
	}
}

func localIPs() string {
	addrs := []string{}
	ifaces, err := netInterfaceAddrs()
	if err != nil {
		return "неизвестен"
	}
	for _, a := range ifaces {
		addrs = append(addrs, a)
	}
	if len(addrs) == 0 {
		return "неизвестен"
	}
	return strings.Join(addrs, ", ")
}
