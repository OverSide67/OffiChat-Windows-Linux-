// offichat-web — OffiChat для ПК в браузере. Запустите программу, интерфейс откроется сам.
//
//	go run ./cmd/offichat-web
//	go run ./cmd/offichat-web -addr 127.0.0.1:9000 -no-open
package main

import (
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"

	"offichat/internal/session"
	"offichat/internal/web"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:8080", "адрес веб-интерфейса (только этот компьютер)")
	noOpen := flag.Bool("no-open", false, "не открывать браузер автоматически")
	flag.Parse()

	dir, err := configDir()
	if err != nil {
		log.Fatal(err)
	}
	s, err := session.New(dir)
	if err != nil {
		log.Fatal(err)
	}

	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Fatalf("не удалось открыть %s: %v\n"+
			"Порт занят: закройте предыдущий запуск OffiChat или запустите с другим портом:\n"+
			"  go run ./cmd/offichat-web -addr 127.0.0.1:9000", *addr, err)
	}

	url := "http://" + *addr
	fmt.Println("OffiChat работает:", url)
	fmt.Println("Чтобы выйти, закройте это окно терминала (Ctrl+C).")
	if !*noOpen {
		openBrowser(url)
	}
	log.Fatal(http.Serve(ln, web.Handler(s)))
}

func configDir() (string, error) {
	base, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(base, "offichat"), nil
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	_ = cmd.Start()
}
