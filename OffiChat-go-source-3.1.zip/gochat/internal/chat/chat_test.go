package chat

import (
	"bufio"
	"encoding/base64"
	"fmt"
	"net"
	"strings"
	"testing"
	"time"

	"offichat/internal/crypt"
)

var testKey = crypt.DeriveKey("тестовый код")

// wait ждёт событие нужного вида и условия.
func wait(t *testing.T, c *Conn, kind string, ok func(Event) bool) Event {
	t.Helper()
	deadline := time.After(5 * time.Second)
	for {
		select {
		case e := <-c.Events():
			if e.Kind == kind && (ok == nil || ok(e)) {
				return e
			}
		case <-deadline:
			t.Fatalf("нет события %q", kind)
		}
	}
}

func pair(t *testing.T, port int) (*Conn, *Conn) {
	t.Helper()
	a := New(func() string { return "Alice" })
	b := New(func() string { return "Bob" })
	a.SetKey(testKey)
	b.SetKey(testKey)
	if err := a.Host(port); err != nil {
		t.Fatal(err)
	}
	b.Connect("127.0.0.1", port)
	wait(t, a, "state", func(e Event) bool { return e.State == "connected" })
	wait(t, b, "state", func(e Event) bool { return e.State == "connected" })
	wait(t, a, "nick", func(e Event) bool { return e.Nick == "Bob" })
	wait(t, b, "nick", func(e Event) bool { return e.Nick == "Alice" })
	return a, b
}

func TestTextDeliveredAndRead(t *testing.T) {
	a, b := pair(t, 5201)
	defer a.Close()
	defer b.Close()

	text := "привет | мир\nвторая строка"
	mid, ok := a.SendText(text)
	if !ok {
		t.Fatal("нет соединения")
	}
	got := wait(t, b, "message", func(e Event) bool { return e.MID == mid })
	if got.Text != text {
		t.Fatalf("текст: %q", got.Text)
	}
	wait(t, a, "status", func(e Event) bool { return e.MID == mid && e.Status == "delivered" })
	b.MarkRead(mid)
	wait(t, a, "status", func(e Event) bool { return e.MID == mid && e.Status == "read" })
}

func TestEditAndDelete(t *testing.T) {
	a, b := pair(t, 5202)
	defer a.Close()
	defer b.Close()

	mid, _ := a.SendText("первый")
	wait(t, b, "message", func(e Event) bool { return e.MID == mid })
	a.Edit(mid, "исправлено")
	if e := wait(t, b, "edit", func(e Event) bool { return e.MID == mid }); e.Text != "исправлено" {
		t.Fatalf("правка: %q", e.Text)
	}
	a.Delete(mid)
	wait(t, b, "delete", func(e Event) bool { return e.MID == mid })
}

func TestTyping(t *testing.T) {
	a, b := pair(t, 5203)
	defer a.Close()
	defer b.Close()

	a.SendTyping(true)
	wait(t, b, "typing", func(e Event) bool { return e.On })
	if !b.IsPeerTyping() {
		t.Fatal("собеседник должен печатать")
	}
	a.SendTyping(false)
	wait(t, b, "typing", func(e Event) bool { return !e.On })
	if b.IsPeerTyping() {
		t.Fatal("печать должна закончиться")
	}
}

func TestDisconnectReported(t *testing.T) {
	a, b := pair(t, 5204)
	defer b.Close()
	a.Close()
	wait(t, b, "state", func(e Event) bool { return e.State == "idle" })
}

func TestHostTwiceAndRehost(t *testing.T) {
	c := New(func() string { return "x" })
	c.SetKey(testKey)
	if err := c.Host(5205); err != nil {
		t.Fatal(err)
	}
	if err := c.Host(5205); err != nil {
		t.Fatalf("повторный Host не должен падать: %v", err)
	}
	c.Close()
	if err := c.Host(5205); err != nil {
		t.Fatalf("после Close порт должен быть свободен: %v", err)
	}
	c.Close()
}

// Сырой клиент говорит строками, как Android: проверяем формат ответа.
func TestAndroidStyleClient(t *testing.T) {
	c := New(func() string { return "Desk" })
	c.SetKey(testKey)
	if err := c.Host(5206); err != nil {
		t.Fatal(err)
	}
	defer c.Close()

	raw, err := net.DialTimeout("tcp", "127.0.0.1:5206", 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer raw.Close()
	hi, _ := crypt.Seal(testKey, "HI|Android")
	msg, _ := crypt.Seal(testKey, fmt.Sprintf("M|abcd1234|%s", base64.StdEncoding.EncodeToString([]byte("из андроида"))))
	raw.Write([]byte(hi + "\n" + msg + "\n"))

	wait(t, c, "nick", func(e Event) bool { return e.Nick == "Android" })
	got := wait(t, c, "message", func(e Event) bool { return e.MID == "abcd1234" })
	if got.Text != "из андроида" {
		t.Fatalf("текст: %q", got.Text)
	}

	r := bufio.NewReader(raw)
	first, _ := r.ReadString('\n')
	if got, err := crypt.Open(testKey, strings.TrimSpace(first)); err != nil || got != "HI|Desk" {
		t.Fatalf("приветствие: %q, %v", got, err)
	}
	second, _ := r.ReadString('\n')
	if got, err := crypt.Open(testKey, strings.TrimSpace(second)); err != nil || got != "D|abcd1234" {
		t.Fatalf("доставка: %q, %v", got, err)
	}
}

func TestCleanNick(t *testing.T) {
	if got := CleanNick("  a|b\nc  "); got != "a_b_c" {
		t.Fatalf("CleanNick = %q", got)
	}
	if got := CleanNick(strings.Repeat("я", 40)); len([]rune(got)) != 24 {
		t.Fatalf("длина ника = %d", len([]rune(got)))
	}
}

func TestNoKeyRefusesToOpen(t *testing.T) {
	c := New(func() string { return "x" })
	if err := c.Host(5207); err == nil {
		t.Fatal("без ключа Host должен возвращать ошибку")
	}
	c.Connect("127.0.0.1", 5207)
	wait(t, c, "state", func(e Event) bool { return strings.Contains(e.Reason, "код шифрования") })
	c.Close()
}

func TestWrongKeyDisconnects(t *testing.T) {
	a := New(func() string { return "Alice" })
	b := New(func() string { return "Bob" })
	a.SetKey(crypt.DeriveKey("один код"))
	b.SetKey(crypt.DeriveKey("другой код"))
	if err := a.Host(5208); err != nil {
		t.Fatal(err)
	}
	b.Connect("127.0.0.1", 5208)
	wait(t, a, "state", func(e Event) bool { return strings.Contains(e.Reason, "Неверный код") })
	wait(t, b, "state", func(e Event) bool { return e.State == "idle" })
	if a.IsConnected() || b.IsConnected() {
		t.Fatal("при неверном коде соединение должно закрываться")
	}
	a.Close()
	b.Close()
}

func TestTrafficIsEncrypted(t *testing.T) {
	// Проверяем, что на проводе нет открытого текста: читаем сырой поток
	c := New(func() string { return "x" })
	c.SetKey(testKey)
	if err := c.Host(5209); err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	raw, _ := net.DialTimeout("tcp", "127.0.0.1:5209", 5*time.Second)
	defer raw.Close()
	c.mu.Lock()
	c.mu.Unlock()
	line, _ := bufio.NewReader(raw).ReadString('\n')
	if strings.Contains(line, "HI|") || !strings.HasPrefix(line, "S|") {
		t.Fatalf("приветствие уходит открытым текстом: %q", line)
	}
}
