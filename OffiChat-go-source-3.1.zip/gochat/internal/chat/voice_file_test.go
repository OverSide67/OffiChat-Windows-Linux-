package chat

import (
	"bytes"
	"testing"
)

func TestFileRoundTrip(t *testing.T) {
	a, b := pair(t, 5221)
	defer a.Close()
	defer b.Close()

	payload := []byte("содержимое файла\x00\x01")
	if !a.SendFile("отчёт|2026.txt", payload) {
		t.Fatal("отправка файла не прошла")
	}
	got := wait(t, b, "file", nil)
	if got.Text != "отчёт_2026.txt" {
		t.Fatalf("имя: %q", got.Text)
	}
	if !bytes.Equal(got.Data, payload) {
		t.Fatal("содержимое файла повреждено")
	}
}

func TestSafeName(t *testing.T) {
	cases := map[string]string{
		"a/b/c.png":     "c.png",
		`C:\dir\x.mp3`:  "x.mp3",
		"  pi|pe.txt  ": "pi_pe.txt",
		"":              "file",
	}
	for in, want := range cases {
		if got := SafeName(in); got != want {
			t.Errorf("SafeName(%q) = %q, want %q", in, got, want)
		}
	}
}

func TestVoiceInviteAndFrames(t *testing.T) {
	a, b := pair(t, 5222)
	defer a.Close()
	defer b.Close()

	frame := make([]byte, VoiceFrameBytes)
	for i := range frame {
		frame[i] = byte(i)
	}
	// Собеседник ещё не в голосе: кадр не уходит
	if a.VoiceJoin(); a.SendVoiceFrame(frame) {
		t.Fatal("кадр не должен уходить, пока собеседник не в голосе")
	}
	wait(t, b, "voice_invite", nil)

	b.VoiceJoin()
	wait(t, a, "voice_peer", func(e Event) bool { return e.On })
	if !a.SendVoiceFrame(frame) {
		t.Fatal("кадр должен уйти, когда оба в голосе")
	}
	got := wait(t, b, "voice_frame", nil)
	if !bytes.Equal(got.Data, frame) {
		t.Fatal("кадр голоса повреждён")
	}

	a.VoiceLeave()
	wait(t, b, "voice_peer", func(e Event) bool { return !e.On })
}

func TestBadVoiceFrameSizeRejected(t *testing.T) {
	a, b := pair(t, 5223)
	defer a.Close()
	defer b.Close()
	a.VoiceJoin()
	b.VoiceJoin()
	wait(t, a, "voice_peer", func(e Event) bool { return e.On })
	if a.SendVoiceFrame(make([]byte, 100)) {
		t.Fatal("кадр не того размера не должен отправляться")
	}
}
