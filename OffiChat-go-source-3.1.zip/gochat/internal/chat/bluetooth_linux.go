//go:build linux

package chat

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const (
	afBluetooth   = 31 // AF_BLUETOOTH
	btprotoRFCOMM = 3  // BTPROTO_RFCOMM
)

// ConnectBluetooth подключается к телефону по RFCOMM. Канал: `sdptool browse MAC`.
func (c *Conn) ConnectBluetooth(mac string, channel int) {
	c.Close()
	c.emit(Event{Kind: "state", State: "connecting", Reason: "Bluetooth " + mac})
	go func() {
		conn, err := dialRFCOMM(mac, channel)
		if err != nil {
			c.emit(Event{Kind: "state", State: "idle", Reason: fmt.Sprintf("Bluetooth: не удалось подключиться (%v)", err)})
			return
		}
		c.attach(conn, "Bluetooth "+mac)
	}()
}

func dialRFCOMM(mac string, channel int) (net.Conn, error) {
	parts := strings.Split(mac, ":")
	if len(parts) != 6 {
		return nil, fmt.Errorf("неверный MAC %q", mac)
	}
	fd, err := syscall.Socket(afBluetooth, syscall.SOCK_STREAM, btprotoRFCOMM)
	if err != nil {
		return nil, err
	}
	// struct sockaddr_rc: family (2 байта, little-endian), bdaddr (6 байт, в обратном порядке), channel (1 байт)
	var sa [10]byte
	sa[0] = afBluetooth
	for i := 0; i < 6; i++ {
		v, err := strconv.ParseUint(parts[5-i], 16, 8)
		if err != nil {
			syscall.Close(fd)
			return nil, fmt.Errorf("неверный MAC %q", mac)
		}
		sa[2+i] = byte(v)
	}
	sa[8] = byte(channel)
	_, _, errno := syscall.Syscall(syscall.SYS_CONNECT, uintptr(fd), uintptr(unsafe.Pointer(&sa[0])), uintptr(len(sa)))
	if errno != 0 {
		syscall.Close(fd)
		return nil, errno
	}
	f := os.NewFile(uintptr(fd), "rfcomm")
	defer f.Close()
	return net.FileConn(f)
}
