// Package chat — сетевое ядро OffiChat. Протокол совпадает с Android-версией (ChatHub.kt):
//
//	M|mid|b64   текст            E|mid|b64  правка            Q|mid   удаление
//	D|mid       доставлено       X|mid      прочитано         P|1/P|0 печатает
//	HI|nick     никнейм при подключении
package chat

import (
	"bufio"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"

	"offichat/internal/crypt"
)

const (
	DefaultPort    = 5000
	typingTTL      = 4 * time.Second
	typingThrottle = 2500 * time.Millisecond
	maxLine        = 16 * 1024 * 1024 // файлы передаются в base64, строки могут быть большими
)

// Event — всё, что ядро сообщает интерфейсу.
type Event struct {
	Kind string // state, nick, local_message, message, edit, delete, status, typing, note,
	// file, voice_invite, voice_invite_cancel, voice_peer, voice_local, voice_frame
	MID    string
	Text   string
	Status string // sent, delivered, read, fail
	State  string // waiting, connecting, connected, idle
	Reason string
	Port   int
	Nick   string
	On     bool
	Data   []byte // содержимое файла или кадр голоса (640 байт, PCM 16 кГц, 16 бит)
}

// Conn — одно соединение с собеседником. Слушает порт или подключается по адресу.
type Conn struct {
	nick   func() string
	events chan Event

	mu          sync.Mutex
	sock        net.Conn
	ln          net.Listener
	peerNick    string
	typingUntil time.Time
	lastTyping  time.Time
	key         []byte // ключ шифрования; без него соединение не открывается
	voiceOn     bool   // я в голосовом канале
	peerVoice   bool   // собеседник в голосовом канале

	wmu sync.Mutex
}

// MaxFile — лимит размера файла, как в Android-версии.
const MaxFile = 15 * 1024 * 1024

// VoiceFrameBytes — один кадр голоса: 20 мс, 16 кГц, моно, 16 бит.
const VoiceFrameBytes = 640

// New создаёт соединение. nick возвращает никнейм этого устройства.
func New(nick func() string) *Conn {
	return &Conn{nick: nick, events: make(chan Event, 512)}
}

// SetKey задаёт ключ шифрования (см. crypt.DeriveKey). Без ключа соединение не открывается.
func (c *Conn) SetKey(key []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.key = key
}

func (c *Conn) hasKey() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.key != nil
}

// Events отдаёт поток событий. Интерфейс обязан его читать.
func (c *Conn) Events() <-chan Event { return c.events }

func (c *Conn) emit(e Event) { c.events <- e }

// ---------- состояние ----------

func (c *Conn) IsConnected() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.sock != nil
}

func (c *Conn) PeerNick() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.peerNick
}

func (c *Conn) IsPeerTyping() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return time.Now().Before(c.typingUntil)
}

// ---------- подключение ----------

// Host начинает слушать порт и ждёт одного собеседника. Повторный вызов безопасен.
func (c *Conn) Host(port int) error {
	if !c.hasKey() {
		return ErrNoKey
	}
	c.mu.Lock()
	if c.ln != nil {
		c.mu.Unlock()
		c.emit(Event{Kind: "state", State: "waiting", Port: port})
		return nil
	}
	c.mu.Unlock()

	ln, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return err
	}
	c.mu.Lock()
	c.ln = ln
	c.mu.Unlock()
	c.emit(Event{Kind: "state", State: "waiting", Port: port})
	go c.acceptLoop(ln)
	return nil
}

func (c *Conn) acceptLoop(ln net.Listener) {
	conn, err := ln.Accept()
	c.mu.Lock()
	still := c.ln == ln
	c.mu.Unlock()
	if err != nil || !still {
		if err == nil {
			conn.Close()
		}
		return
	}
	c.attach(conn, hostOf(conn.RemoteAddr()))
}

// Connect подключается к собеседнику по IP или имени хоста.
func (c *Conn) Connect(host string, port int) {
	if !c.hasKey() {
		c.emit(Event{Kind: "state", State: "idle", Reason: "Задайте код шифрования в настройках"})
		return
	}
	c.Close()
	c.emit(Event{Kind: "state", State: "connecting", Reason: host})
	go func() {
		conn, err := net.DialTimeout("tcp", net.JoinHostPort(host, strconv.Itoa(port)), 8*time.Second)
		if err != nil {
			c.emit(Event{Kind: "state", State: "idle", Reason: "Не удалось подключиться: " + err.Error()})
			return
		}
		c.attach(conn, host)
	}()
}

// Close отключает соединение и останавливает ожидание.
func (c *Conn) Close() {
	c.mu.Lock()
	ln, sock := c.ln, c.sock
	c.ln, c.sock = nil, nil
	c.peerNick = ""
	wasVoice := c.voiceOn
	c.voiceOn, c.peerVoice = false, false
	c.mu.Unlock()

	if ln != nil {
		ln.Close()
	}
	if sock != nil {
		sock.Close()
		if wasVoice {
			c.emit(Event{Kind: "voice_local", On: false})
		}
		c.emit(Event{Kind: "voice_peer", On: false})
		c.emit(Event{Kind: "state", State: "idle", Reason: "Отключено"})
	} else if ln != nil {
		c.emit(Event{Kind: "state", State: "idle", Reason: "Ожидание остановлено"})
	}
}

// attach — общий путь для TCP и Bluetooth: одно соединение, приветствие, чтение.
func (c *Conn) attach(conn net.Conn, addr string) {
	c.mu.Lock()
	old := c.sock
	c.sock = conn
	c.peerNick = ""
	ln := c.ln
	c.ln = nil // одно соединение на сеанс ожидания, порт освобождаем
	c.mu.Unlock()

	if ln != nil {
		ln.Close()
	}
	if old != nil {
		old.Close()
	}
	if tc, ok := conn.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
	}
	c.emit(Event{Kind: "state", State: "connected", Reason: addr})
	c.sendRaw("HI|" + CleanNick(c.nick()))
	go c.readLoop(conn)
}

func (c *Conn) readLoop(conn net.Conn) {
	sc := bufio.NewScanner(conn)
	sc.Buffer(make([]byte, 64*1024), maxLine)
	c.mu.Lock()
	key := c.key
	c.mu.Unlock()
	for sc.Scan() {
		raw := strings.TrimRight(sc.Text(), "\r")
		line := raw
		if key != nil {
			plain, err := crypt.Open(key, raw)
			if err != nil {
				// Неверный код или чужая версия протокола: сообщаем причину и закрываем соединение
				c.mu.Lock()
				mine := c.sock == conn
				c.mu.Unlock()
				if mine {
					c.emit(Event{Kind: "state", State: "idle", Reason: "Неверный код шифрования или чужая версия приложения"})
				}
				break
			}
			line = plain
		}
		c.dispatch(line)
	}
	c.mu.Lock()
	mine := c.sock == conn
	wasVoice := false
	if mine {
		c.sock = nil
		c.peerNick = ""
		wasVoice = c.voiceOn
		c.voiceOn, c.peerVoice = false, false
	}
	c.mu.Unlock()
	conn.Close()
	if mine {
		if wasVoice {
			c.emit(Event{Kind: "voice_local", On: false})
		}
		c.emit(Event{Kind: "voice_peer", On: false})
		c.emit(Event{Kind: "state", State: "idle", Reason: "Соединение разорвано"})
	}
}

// ---------- приём ----------

func (c *Conn) dispatch(line string) {
	switch {
	case strings.HasPrefix(line, "M|"):
		p := strings.SplitN(line, "|", 3)
		if len(p) == 3 {
			if text, ok := unb64(p[2]); ok {
				c.sendRaw("D|" + p[1])
				c.emit(Event{Kind: "message", MID: p[1], Text: text})
			}
		}
	case strings.HasPrefix(line, "E|"):
		p := strings.SplitN(line, "|", 3)
		if len(p) == 3 {
			if text, ok := unb64(p[2]); ok {
				c.emit(Event{Kind: "edit", MID: p[1], Text: text})
			}
		}
	case strings.HasPrefix(line, "Q|"):
		c.emit(Event{Kind: "delete", MID: line[2:]})
	case strings.HasPrefix(line, "D|"):
		c.emit(Event{Kind: "status", MID: line[2:], Status: "delivered"})
	case strings.HasPrefix(line, "X|"):
		c.emit(Event{Kind: "status", MID: line[2:], Status: "read"})
	case line == "P|1":
		c.mu.Lock()
		c.typingUntil = time.Now().Add(typingTTL)
		c.mu.Unlock()
		c.emit(Event{Kind: "typing", On: true})
	case line == "P|0":
		c.mu.Lock()
		c.typingUntil = time.Time{}
		c.mu.Unlock()
		c.emit(Event{Kind: "typing", On: false})
	case strings.HasPrefix(line, "HI|"):
		nick := CleanNick(line[3:])
		c.mu.Lock()
		c.peerNick = nick
		c.mu.Unlock()
		c.emit(Event{Kind: "nick", Nick: nick})
	case strings.HasPrefix(line, "F|"):
		p := strings.SplitN(line, "|", 3)
		if len(p) == 3 {
			if data, err := base64.StdEncoding.DecodeString(p[2]); err == nil {
				c.emit(Event{Kind: "file", Text: SafeName(p[1]), Data: data})
			}
		}
	case line == "VJ|1":
		c.mu.Lock()
		c.peerVoice = true
		on := c.voiceOn
		c.mu.Unlock()
		if on {
			c.sendRaw("VH|1") // отвечаем, что уже в голосе
		} else {
			c.emit(Event{Kind: "voice_invite"})
		}
		c.emit(Event{Kind: "voice_peer", On: true})
	case line == "VJ|0":
		c.mu.Lock()
		c.peerVoice = false
		c.mu.Unlock()
		c.emit(Event{Kind: "voice_peer", On: false})
		c.emit(Event{Kind: "voice_invite_cancel"})
	case line == "VH|1":
		c.mu.Lock()
		c.peerVoice = true
		c.mu.Unlock()
		c.emit(Event{Kind: "voice_peer", On: true})
	case strings.HasPrefix(line, "VA|"):
		c.mu.Lock()
		ok := c.voiceOn && c.peerVoice
		c.mu.Unlock()
		if ok {
			if data, err := base64.StdEncoding.DecodeString(line[3:]); err == nil && len(data) == VoiceFrameBytes {
				c.emit(Event{Kind: "voice_frame", Data: data})
			}
		}
	case line != "":
		c.emit(Event{Kind: "message", Text: line}) // старый формат без идентификатора
	}
}

// ---------- отправка ----------

func (c *Conn) sendRaw(line string) bool {
	c.mu.Lock()
	s := c.sock
	key := c.key
	c.mu.Unlock()
	if s == nil {
		return false
	}
	out := line
	if key != nil {
		wire, err := crypt.Seal(key, line)
		if err != nil {
			return false
		}
		out = wire
	}
	c.wmu.Lock()
	defer c.wmu.Unlock()
	_, err := s.Write([]byte(out + "\n"))
	return err == nil
}

// ErrNoKey — соединение нельзя открыть без кода шифрования.
var ErrNoKey = errNoKey{}

type errNoKey struct{}

func (errNoKey) Error() string { return "не задан код шифрования" }

// SendText отправляет текст. Возвращает идентификатор сообщения и false, если нет соединения.
func (c *Conn) SendText(text string) (string, bool) {
	if !c.IsConnected() {
		return "", false
	}
	mid := newMID()
	c.emit(Event{Kind: "local_message", MID: mid, Text: text, Status: "sent"})
	if !c.sendRaw("M|" + mid + "|" + b64(text)) {
		c.emit(Event{Kind: "status", MID: mid, Status: "fail"})
	}
	return mid, true
}

// Edit отправляет правку своего сообщения.
func (c *Conn) Edit(mid, text string) bool {
	return c.sendRaw("E|" + mid + "|" + b64(text))
}

// Delete удаляет своё сообщение у обеих сторон.
func (c *Conn) Delete(mid string) bool {
	return c.sendRaw("Q|" + mid)
}

// MarkRead сообщает собеседнику, что его сообщение прочитано.
func (c *Conn) MarkRead(mid string) bool {
	return c.sendRaw("X|" + mid)
}

// SendTyping сообщает о наборе текста, не чаще раза в 2,5 секунды.
func (c *Conn) SendTyping(on bool) {
	c.mu.Lock()
	now := time.Now()
	if on {
		if now.Sub(c.lastTyping) < typingThrottle {
			c.mu.Unlock()
			return
		}
		c.lastTyping = now
		c.mu.Unlock()
		c.sendRaw("P|1")
		return
	}
	if c.lastTyping.IsZero() {
		c.mu.Unlock()
		return
	}
	c.lastTyping = time.Time{}
	c.mu.Unlock()
	c.sendRaw("P|0")
}

// SendFile отправляет файл. Возвращает false, если нет соединения.
func (c *Conn) SendFile(name string, data []byte) bool {
	if !c.IsConnected() {
		return false
	}
	return c.sendRaw("F|" + SafeName(name) + "|" + base64.StdEncoding.EncodeToString(data))
}

// VoiceJoin входит в голосовой канал и сообщает собеседнику (VJ|1).
func (c *Conn) VoiceJoin() bool {
	c.mu.Lock()
	if c.sock == nil {
		c.mu.Unlock()
		return false
	}
	if c.voiceOn {
		c.mu.Unlock()
		return true
	}
	c.voiceOn = true
	c.mu.Unlock()
	c.sendRaw("VJ|1")
	c.emit(Event{Kind: "voice_local", On: true})
	return true
}

// VoiceLeave выходит из голосового канала (VJ|0).
func (c *Conn) VoiceLeave() {
	c.mu.Lock()
	was := c.voiceOn
	c.voiceOn = false
	c.mu.Unlock()
	if was {
		c.sendRaw("VJ|0")
		c.emit(Event{Kind: "voice_local", On: false})
	}
}

// SendVoiceFrame отправляет кадр голоса, если оба в голосовом канале.
func (c *Conn) SendVoiceFrame(pcm []byte) bool {
	c.mu.Lock()
	ok := c.voiceOn && c.peerVoice
	c.mu.Unlock()
	if !ok || len(pcm) != VoiceFrameBytes {
		return false
	}
	return c.sendRaw("VA|" + base64.StdEncoding.EncodeToString(pcm))
}

// SafeName — то же правило, что safeName() в Android: без путей и разделителя протокола.
func SafeName(n string) string {
	base := n
	if i := strings.LastIndexAny(n, `/\`); i >= 0 {
		base = n[i+1:]
	}
	base = strings.TrimSpace(base)
	base = strings.NewReplacer("|", "_", "\n", "_", "\r", "_").Replace(base)
	if base == "" {
		return "file"
	}
	return base
}

// ---------- утилиты ----------

// CleanNick убирает разделитель протокола и переводы строк, не длиннее 24 символов.
func CleanNick(s string) string {
	r := strings.NewReplacer("|", "_", "\r", "_", "\n", "_")
	s = strings.TrimSpace(r.Replace(s))
	if utf8.RuneCountInString(s) > 24 {
		s = string([]rune(s)[:24])
	}
	return s
}

func b64(s string) string { return base64.StdEncoding.EncodeToString([]byte(s)) }

func unb64(s string) (string, bool) {
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil || !utf8.Valid(b) {
		return "", false
	}
	return string(b), true
}

func newMID() string {
	b := make([]byte, 4)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func hostOf(a net.Addr) string {
	h, _, err := net.SplitHostPort(a.String())
	if err != nil {
		return a.String()
	}
	return h
}
