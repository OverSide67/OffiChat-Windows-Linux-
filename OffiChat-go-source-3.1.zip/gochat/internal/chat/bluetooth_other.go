//go:build !linux

package chat

// ConnectBluetooth на Windows и macOS недоступен: стандартной поддержки RFCOMM в Go нет.
func (c *Conn) ConnectBluetooth(mac string, channel int) {
	c.emit(Event{Kind: "state", State: "idle", Reason: "Bluetooth поддерживается только в Linux"})
}
