// Package history хранит переписку на диске. Системные строки между сеансами не сохраняются.
package history

import (
	"encoding/json"
	"os"
	"path/filepath"
)

type Message struct {
	ID     string `json:"id"`
	From   string `json:"from"` // me, peer, system
	Text   string `json:"text"`
	Time   string `json:"time"`
	MID    string `json:"mid"`
	Status string `json:"status"`
	Edited bool   `json:"edited"`
	Kind   string `json:"kind,omitempty"` // text, image, audio, video, file
	Path   string `json:"path,omitempty"` // имя файла в каталоге files/
}

// DefaultPath: ~/.config/offichat/history.json (Linux), аналоги в Windows и macOS.
func DefaultPath() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "offichat", "history.json"), nil
}

func Load(path string) ([]Message, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var all []Message
	if err := json.Unmarshal(data, &all); err != nil {
		return nil, err
	}
	var out []Message
	for _, m := range all {
		if m.From != "system" {
			out = append(out, m)
		}
	}
	return out, nil
}

// Save пишет атомарно: сначала временный файл, потом переименование.
func Save(path string, msgs []Message) error {
	keep := make([]Message, 0, len(msgs))
	for _, m := range msgs {
		if m.From != "system" {
			keep = append(keep, m)
		}
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(keep, "", " ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}
