package history

import (
	"path/filepath"
	"testing"
)

func TestSystemMessagesNotStored(t *testing.T) {
	path := filepath.Join(t.TempDir(), "h.json")
	msgs := []Message{
		{ID: "1", From: "system", Text: "Подключено"},
		{ID: "2", From: "me", Text: "привет", MID: "m1", Status: "read"},
	}
	if err := Save(path, msgs); err != nil {
		t.Fatal(err)
	}
	got, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Text != "привет" || got[0].Status != "read" {
		t.Fatalf("после загрузки: %+v", got)
	}
}
