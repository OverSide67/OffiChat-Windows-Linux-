// Package crypt шифрует строки протокола OffiChat.
//
// Ключ AES-256 выводится из общего кода (PBKDF2-HMAC-SHA256). Каждая строка шифруется AES-GCM
// со случайным nonce. Формат на проводе: "S|" + base64(nonce || шифртекст || тег).
package crypt

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"strings"
)

const (
	Prefix     = "S|"
	salt       = "offichat-v1"
	iterations = 100000
	keyLen     = 32
)

var ErrBadMessage = errors.New("сообщение повреждено или зашифровано другим ключом")

// DeriveKey превращает общий код в ключ. Одинаковый код на обоих устройствах даёт одинаковый ключ.
func DeriveKey(passphrase string) []byte {
	return pbkdf2([]byte(passphrase), []byte(salt), iterations, keyLen)
}

// Seal шифрует строку и возвращает строку для отправки по сети.
func Seal(key []byte, line string) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	sealed := gcm.Seal(nonce, nonce, []byte(line), nil)
	return Prefix + base64.StdEncoding.EncodeToString(sealed), nil
}

// Open расшифровывает строку из сети. Ошибка означает неверный ключ или подмену.
func Open(key []byte, wire string) (string, error) {
	if !strings.HasPrefix(wire, Prefix) {
		return "", ErrBadMessage
	}
	raw, err := base64.StdEncoding.DecodeString(wire[len(Prefix):])
	if err != nil {
		return "", ErrBadMessage
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(raw) < gcm.NonceSize() {
		return "", ErrBadMessage
	}
	nonce, body := raw[:gcm.NonceSize()], raw[gcm.NonceSize():]
	plain, err := gcm.Open(nil, nonce, body, nil)
	if err != nil {
		return "", ErrBadMessage
	}
	return string(plain), nil
}

// pbkdf2 — PBKDF2 с HMAC-SHA256 (RFC 8018), на стандартной библиотеке.
func pbkdf2(password, salt []byte, iter, keyLen int) []byte {
	prf := hmac.New(sha256.New, password)
	hashLen := prf.Size()
	blocks := (keyLen + hashLen - 1) / hashLen
	out := make([]byte, 0, blocks*hashLen)
	var counter [4]byte
	for block := 1; block <= blocks; block++ {
		prf.Reset()
		prf.Write(salt)
		binary.BigEndian.PutUint32(counter[:], uint32(block))
		prf.Write(counter[:])
		u := prf.Sum(nil)
		t := make([]byte, len(u))
		copy(t, u)
		for n := 2; n <= iter; n++ {
			prf.Reset()
			prf.Write(u)
			u = prf.Sum(nil)
			for i := range t {
				t[i] ^= u[i]
			}
		}
		out = append(out, t...)
	}
	return out[:keyLen]
}
