package crypt

import (
	"encoding/hex"
	"strings"
	"testing"
)

// Контрольный вектор PBKDF2-HMAC-SHA256 (RFC 7914, раздел 11): "passwd", "salt", 1 итерация, 64 байта.
func TestPBKDF2Vector(t *testing.T) {
	want := "55ac046e56e3089fec1691c22544b605f94185216dde0465e68b9d57c20dacbc49ca9cccf179b645991664b39d77ef317c71b845b1e30bd509112041d3a19783"
	got := hex.EncodeToString(pbkdf2([]byte("passwd"), []byte("salt"), 1, 64))
	if got != want {
		t.Fatalf("pbkdf2 неверен:\n%s", got)
	}
}

func TestSealOpenRoundTrip(t *testing.T) {
	key := DeriveKey("общий код 42")
	line := "M|abcd1234|привет | мир"
	wire, err := Seal(key, line)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasPrefix(wire, Prefix) || strings.Contains(wire, "привет") {
		t.Fatal("в сети не должно быть открытого текста")
	}
	got, err := Open(key, wire)
	if err != nil || got != line {
		t.Fatalf("Open = %q, %v", got, err)
	}
}

func TestWrongKeyRejected(t *testing.T) {
	wire, _ := Seal(DeriveKey("один"), "секрет")
	if _, err := Open(DeriveKey("другой"), wire); err == nil {
		t.Fatal("чужой ключ должен отвергаться")
	}
}

func TestTamperingRejected(t *testing.T) {
	key := DeriveKey("код")
	wire, _ := Seal(key, "проверка")
	b := []byte(wire)
	b[len(b)-3] ^= 1 // меняем один бит в середине шифртекста
	if _, err := Open(key, string(b)); err == nil {
		t.Fatal("подмена должна обнаруживаться")
	}
}

func TestPlaintextRejected(t *testing.T) {
	if _, err := Open(DeriveKey("код"), "M|x|eA=="); err == nil {
		t.Fatal("открытый текст без префикса S| должен отвергаться")
	}
}
