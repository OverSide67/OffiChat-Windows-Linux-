// Package session держит состояние для одного пользователя: соединение, сообщения, настройки.
// Веб-интерфейс и любой другой клиент работают через Session, а не напрямую с chat.Conn.
package session

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"

	"offichat/internal/chat"
	"offichat/internal/crypt"
	"offichat/internal/history"
)

var nickRE = regexp.MustCompile(`^[A-Za-z0-9_]{3,24}$`)

type settings struct {
	Nick       string `json:"nick"`
	Onboarded  bool   `json:"onboarded"`
	LastIP     string `json:"lastIp"`
	Passphrase string `json:"passphrase"` // общий код шифрования; хранится локально, файл с правами 0600
}

// MinPassphrase — минимальная длина общего кода.
const MinPassphrase = 6

// Snapshot — всё, что нужно интерфейсу, одним объектом.
type Snapshot struct {
	Nick        string            `json:"nick"`
	Onboarded   bool              `json:"onboarded"`
	LastIP      string            `json:"lastIp"`
	BTSupported bool              `json:"btSupported"`
	State       string            `json:"state"`
	Reason      string            `json:"reason"`
	Port        int               `json:"port"`
	LocalIPs    string            `json:"localIps"`
	HasKey      bool              `json:"hasKey"`
	Connected   bool              `json:"connected"`
	PeerNick    string            `json:"peerNick"`
	Typing      bool              `json:"typing"`
	Messages    []history.Message `json:"messages"`
	VoiceLocal  bool              `json:"voiceLocal"`
	VoicePeer   bool              `json:"voicePeer"`
	Invite      bool              `json:"invite"`
}

type Session struct {
	dir      string
	chatPort int
	conn     *chat.Conn

	mu       sync.Mutex
	set      settings
	msgs     []history.Message
	state    string
	reason   string
	port     int
	subs     map[chan []byte]struct{}
	vsubs    map[chan []byte]struct{} // подписчики на кадры голоса (бинарные)
	lastType bool
	invite   bool
	vLocal   bool
	vPeer    bool
}

// New создаёт сессию с настройками и историей в каталоге dir.
func New(dir string) (*Session, error) {
	return NewWithPort(dir, chat.DefaultPort)
}

// NewWithPort — то же, но с другим портом чата (нужно тестам).
func NewWithPort(dir string, chatPort int) (*Session, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	msgs, err := history.Load(filepath.Join(dir, "history.json"))
	if err != nil {
		msgs = nil // повреждённая история не должна блокировать запуск
	}
	s := &Session{
		dir:      dir,
		chatPort: chatPort,
		msgs:     msgs,
		state:    "idle",
		reason:   "Нет подключения",
		port:     chatPort,
		subs:     map[chan []byte]struct{}{},
		vsubs:    map[chan []byte]struct{}{},
	}
	s.set = loadSettings(filepath.Join(dir, "settings.json"))
	s.conn = chat.New(s.Nick)
	if s.set.Passphrase != "" {
		s.conn.SetKey(crypt.DeriveKey(s.set.Passphrase))
	}
	go s.loop()
	go s.ticker()
	return s, nil
}

func (s *Session) loop() {
	for e := range s.conn.Events() {
		s.apply(e)
	}
}

// ticker отправляет обновление, когда собеседник начинает или перестаёт печатать.
func (s *Session) ticker() {
	for range time.Tick(time.Second) {
		s.mu.Lock()
		if t := s.conn.IsPeerTyping(); t != s.lastType {
			s.lastType = t
			s.broadcastLocked()
		}
		s.mu.Unlock()
	}
}

func (s *Session) apply(e chat.Event) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e.Kind == "voice_frame" {
		// кадры идут часто, поэтому не сохраняем и не рассылаем полное состояние
		for ch := range s.vsubs {
			select {
			case ch <- e.Data:
			default:
			}
		}
		return
	}
	switch e.Kind {
	case "state":
		s.state, s.reason = e.State, e.Reason
		if e.State == "idle" {
			s.invite, s.vLocal, s.vPeer = false, false, false
		}
		if e.Port != 0 {
			s.port = e.Port
		}
		switch e.State {
		case "waiting":
			s.reason = fmt.Sprintf("Ждём собеседника на порту %d", e.Port)
		case "connecting":
			s.reason = "Подключаемся к " + e.Reason
		case "connected":
			s.reason = "Подключено"
			s.addLocked("system", "Подключено", "", "")
		}
	case "local_message":
		s.addLocked("me", e.Text, e.MID, "sent")
	case "message":
		s.addLocked("peer", e.Text, e.MID, "")
		if e.MID != "" && len(s.subs) > 0 {
			s.conn.MarkRead(e.MID) // пользователь видит экран — сообщение прочитано
		}
	case "status":
		for i := range s.msgs {
			m := &s.msgs[i]
			if m.From == "me" && m.MID == e.MID {
				if e.Status == "fail" || rank(e.Status) > rank(m.Status) {
					m.Status = e.Status
				}
			}
		}
	case "edit":
		for i := range s.msgs {
			m := &s.msgs[i]
			if m.From == "peer" && m.MID == e.MID {
				m.Text, m.Edited = e.Text, true
			}
		}
	case "delete":
		s.removeLocked(func(m history.Message) bool { return m.From == "peer" && m.MID == e.MID })
	case "note":
		s.addLocked("system", e.Text, "", "")
	case "file":
		name, err := s.storeFile("", e.Text, e.Data)
		if err == nil {
			s.addFileLocked("peer", e.Text, name, "")
		} else {
			s.addLocked("system", "Файл не удалось принять: "+err.Error(), "", "")
		}
	case "voice_invite":
		s.invite = true
	case "voice_invite_cancel":
		s.invite = false
	case "voice_local":
		s.vLocal = e.On
		if e.On {
			s.invite = false
		}
	case "voice_peer":
		s.vPeer = e.On
		if !e.On {
			s.invite = false
		}
	}
	s.saveHistoryLocked()
	s.broadcastLocked()
}

func kindOf(name string) string {
	switch strings.ToLower(filepath.Ext(name)) {
	case ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp":
		return "image"
	case ".mp4", ".webm", ".mov", ".mkv", ".3gp":
		return "video"
	case ".m4a", ".aac", ".mp3", ".ogg", ".wav":
		return "audio"
	}
	return "file"
}

// storeFile сохраняет файл в каталог files/ и возвращает имя, под которым он лежит.
func (s *Session) storeFile(prefix, name string, data []byte) (string, error) {
	dir := filepath.Join(s.dir, "files")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	stored := time.Now().Format("20060102_150405") + "_" + prefix + chat.SafeName(name)
	if err := os.WriteFile(filepath.Join(dir, stored), data, 0o644); err != nil {
		return "", err
	}
	return stored, nil
}

func (s *Session) addFileLocked(from, name, stored, mid string) {
	s.msgs = append(s.msgs, history.Message{
		ID: newID(), From: from, Text: name, Time: time.Now().Format("15:04"),
		MID: mid, Kind: kindOf(name), Path: stored,
	})
}

func rank(st string) int {
	switch st {
	case "sent":
		return 1
	case "delivered":
		return 2
	case "read":
		return 3
	}
	return 0
}

func (s *Session) addLocked(from, text, mid, status string) {
	s.msgs = append(s.msgs, history.Message{
		ID: newID(), From: from, Text: text, Time: time.Now().Format("15:04"), MID: mid, Status: status,
	})
}

func (s *Session) removeLocked(drop func(history.Message) bool) {
	kept := s.msgs[:0]
	for _, m := range s.msgs {
		if !drop(m) {
			kept = append(kept, m)
		}
	}
	s.msgs = kept
}

func (s *Session) saveHistoryLocked() {
	_ = history.Save(filepath.Join(s.dir, "history.json"), s.msgs)
}

func (s *Session) snapshotLocked() Snapshot {
	msgs := make([]history.Message, len(s.msgs))
	copy(msgs, s.msgs)
	return Snapshot{
		Nick:        s.set.Nick,
		Onboarded:   s.set.Onboarded,
		LastIP:      s.set.LastIP,
		BTSupported: runtime.GOOS == "linux",
		State:       s.state,
		Reason:      s.reason,
		Port:        s.port,
		LocalIPs:    localIPs(),
		HasKey:      s.set.Passphrase != "",
		Connected:   s.conn.IsConnected(),
		PeerNick:    s.conn.PeerNick(),
		Typing:      s.conn.IsPeerTyping(),
		Messages:    msgs,
		VoiceLocal:  s.vLocal,
		VoicePeer:   s.vPeer,
		Invite:      s.invite,
	}
}

// Snapshot возвращает текущее состояние.
func (s *Session) Snapshot() Snapshot {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.snapshotLocked()
}

func (s *Session) broadcastLocked() {
	data, _ := json.Marshal(s.snapshotLocked())
	for ch := range s.subs {
		select {
		case ch <- data:
		default: // медленный клиент пропустит обновление, следующее догонит
		}
	}
}

// Subscribe подписывает на обновления. Первым приходит текущее состояние.
func (s *Session) Subscribe() (<-chan []byte, func()) {
	ch := make(chan []byte, 64)
	s.mu.Lock()
	s.subs[ch] = struct{}{}
	data, _ := json.Marshal(s.snapshotLocked())
	s.mu.Unlock()
	ch <- data
	return ch, func() {
		s.mu.Lock()
		delete(s.subs, ch)
		s.mu.Unlock()
	}
}

// SubscribeVoice отдаёт кадры голоса собеседника (640 байт PCM 16 кГц).
func (s *Session) SubscribeVoice() (<-chan []byte, func()) {
	ch := make(chan []byte, 32)
	s.mu.Lock()
	s.vsubs[ch] = struct{}{}
	s.mu.Unlock()
	return ch, func() {
		s.mu.Lock()
		delete(s.vsubs, ch)
		s.mu.Unlock()
	}
}

// SendVoiceFrame отправляет кадр своего голоса собеседнику.
func (s *Session) SendVoiceFrame(pcm []byte) bool {
	return s.conn.SendVoiceFrame(pcm)
}

func (s *Session) VoiceJoin() bool {
	s.mu.Lock()
	s.invite = false
	s.mu.Unlock()
	return s.conn.VoiceJoin()
}

func (s *Session) VoiceLeave() {
	s.conn.VoiceLeave()
}

// VoiceDecline отклоняет приглашение в голосовой чат.
func (s *Session) VoiceDecline() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.invite = false
	s.broadcastLocked()
}

// FilesDir — каталог, где лежат полученные и отправленные файлы.
func (s *Session) FilesDir() string {
	return filepath.Join(s.dir, "files")
}

// SendFile отправляет файл собеседнику и сохраняет копию у себя.
func (s *Session) SendFile(name string, data []byte) error {
	if len(data) > chat.MaxFile {
		return fmt.Errorf("файл больше 15 МБ")
	}
	if !s.conn.SendFile(name, data) {
		return fmt.Errorf("нет соединения с собеседником")
	}
	stored, err := s.storeFile("sent_", name, data)
	if err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.addFileLocked("me", chat.SafeName(name), stored, "")
	s.saveHistoryLocked()
	s.broadcastLocked()
	return nil
}

// ---------- действия ----------

func (s *Session) Host() error {
	return s.conn.Host(s.chatPort)
}

func (s *Session) Connect(host string) {
	s.mu.Lock()
	s.set.LastIP = host
	s.saveSettingsLocked()
	s.mu.Unlock()
	s.conn.Connect(host, s.chatPort)
}

func (s *Session) ConnectBluetooth(mac string, channel int) {
	s.conn.ConnectBluetooth(mac, channel)
}

func (s *Session) Close() {
	s.conn.Close()
}

func (s *Session) Send(text string) bool {
	_, ok := s.conn.SendText(text)
	return ok
}

// Edit правит своё сообщение. Локально меняем сразу, собеседнику уходит строка E|.
func (s *Session) Edit(mid, text string) bool {
	if !s.conn.Edit(mid, text) {
		return false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.msgs {
		if s.msgs[i].From == "me" && s.msgs[i].MID == mid {
			s.msgs[i].Text, s.msgs[i].Edited = text, true
		}
	}
	s.saveHistoryLocked()
	s.broadcastLocked()
	return true
}

// Delete удаляет своё сообщение: у себя сразу, у собеседника, если он на связи.
func (s *Session) Delete(mid string) {
	s.conn.Delete(mid)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.removeLocked(func(m history.Message) bool { return m.From == "me" && m.MID == mid })
	s.saveHistoryLocked()
	s.broadcastLocked()
}

func (s *Session) Typing(on bool) {
	s.conn.SendTyping(on)
}

func (s *Session) SetNick(nick string) error {
	if !nickRE.MatchString(nick) {
		return fmt.Errorf("никнейм: 3–24 символа, латиница, цифры или _")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.set.Nick = nick
	s.saveSettingsLocked()
	s.broadcastLocked()
	return nil
}

// SetPassphrase задаёт общий код шифрования. Тот же код нужно ввести на телефоне.
func (s *Session) SetPassphrase(p string) error {
	if len([]rune(p)) < MinPassphrase {
		return fmt.Errorf("код шифрования: минимум %d символов", MinPassphrase)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.set.Passphrase = p
	s.saveSettingsLocked()
	s.conn.SetKey(crypt.DeriveKey(p))
	s.broadcastLocked()
	return nil
}

func (s *Session) SetOnboarded(v bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.set.Onboarded = v
	s.saveSettingsLocked()
	s.broadcastLocked()
}

// Nick — никнейм этого компьютера. По умолчанию имя машины.
func (s *Session) Nick() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.set.Nick != "" {
		return s.set.Nick
	}
	host, err := os.Hostname()
	if err != nil || host == "" {
		return "pc"
	}
	if len(host) > 24 {
		host = host[:24]
	}
	return host
}

func (s *Session) saveSettingsLocked() {
	data, _ := json.MarshalIndent(s.set, "", " ")
	_ = os.WriteFile(filepath.Join(s.dir, "settings.json"), data, 0o600)
}

func loadSettings(path string) settings {
	var st settings
	if data, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(data, &st)
	}
	return st
}

// ---------- утилиты ----------

func newID() string {
	b := make([]byte, 8)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func localIPs() string {
	addrs, err := netInterfaceIPs()
	if err != nil || len(addrs) == 0 {
		return "неизвестен"
	}
	out := ""
	for i, a := range addrs {
		if i > 0 {
			out += ", "
		}
		out += a
	}
	return out
}
