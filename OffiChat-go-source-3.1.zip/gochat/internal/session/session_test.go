package session

import (
	"strings"
	"testing"
	"time"
)

func waitFor(t *testing.T, what string, cond func() bool) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("не дождались: %s", what)
}

func hasText(s *Session, text string) bool {
	for _, m := range s.Snapshot().Messages {
		if m.Text == text {
			return true
		}
	}
	return false
}

func TestTwoSessionsExchangeMessages(t *testing.T) {
	a, err := NewWithPort(t.TempDir(), 5311)
	if err != nil {
		t.Fatal(err)
	}
	b, err := NewWithPort(t.TempDir(), 5311)
	if err != nil {
		t.Fatal(err)
	}
	for _, x := range []*Session{a, b} {
		if err := x.SetPassphrase("общий код 42"); err != nil {
			t.Fatal(err)
		}
	}
	if err := a.Host(); err != nil {
		t.Fatal(err)
	}
	b.Connect("127.0.0.1")
	waitFor(t, "соединение", func() bool { return a.Snapshot().Connected && b.Snapshot().Connected })

	if !a.Send("привет из теста") {
		t.Fatal("отправка не прошла")
	}
	waitFor(t, "сообщение у собеседника", func() bool { return hasText(b, "привет из теста") })
	waitFor(t, "статус доставлено", func() bool {
		for _, m := range a.Snapshot().Messages {
			if m.From == "me" && m.Status == "delivered" {
				return true
			}
		}
		return false
	})
	if err := a.SetNick("bad nick!"); err == nil {
		t.Fatal("неверный никнейм должен отклоняться")
	}
	if err := a.SetNick("ivan_pc"); err != nil {
		t.Fatal(err)
	}
	if a.Nick() != "ivan_pc" {
		t.Fatalf("никнейм = %q", a.Nick())
	}
	a.Close()
	b.Close()
	waitFor(t, "отключение обработано", func() bool {
		return a.Snapshot().State == "idle" && b.Snapshot().State == "idle"
	})
}

func TestSettingsAndHistorySurviveRestart(t *testing.T) {
	dir := t.TempDir()
	s, err := NewWithPort(dir, 5312)
	if err != nil {
		t.Fatal(err)
	}
	s.SetOnboarded(true)
	if err := s.SetPassphrase("общий код 42"); err != nil {
		t.Fatal(err)
	}
	s.Connect("127.0.0.1") // порт 5312 никто не слушает: попытка быстро завершится отказом
	waitFor(t, "отказ в подключении обработан", func() bool {
		return strings.HasPrefix(s.Snapshot().Reason, "Не удалось подключиться")
	})
	s.Close()
	waitFor(t, "отключение обработано", func() bool { return s.Snapshot().State == "idle" })

	again, err := NewWithPort(dir, 5312)
	if err != nil {
		t.Fatal(err)
	}
	snap := again.Snapshot()
	if !snap.Onboarded || snap.LastIP != "127.0.0.1" || !snap.HasKey {
		t.Fatalf("настройки не сохранились: %+v", snap)
	}
	for _, m := range snap.Messages {
		if m.From == "system" && strings.Contains(m.Text, "Подключено") {
			t.Fatal("системные строки не должны переживать перезапуск")
		}
	}
}

func TestShortPassphraseRejected(t *testing.T) {
	s, _ := NewWithPort(t.TempDir(), 5313)
	if err := s.SetPassphrase("123"); err == nil {
		t.Fatal("короткий код должен отклоняться")
	}
	s.Close()
}
