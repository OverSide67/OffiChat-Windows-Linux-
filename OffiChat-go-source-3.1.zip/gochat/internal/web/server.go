// Package web отдаёт интерфейс в браузере и API для него. Слушает только localhost.
package web

import (
	"embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/fs"
	"net/http"
	"path/filepath"

	"offichat/internal/session"
)

//go:embed static
var static embed.FS

// Handler собирает маршруты: статика, состояние, события (SSE) и действия (POST).
func Handler(s *session.Session) http.Handler {
	mux := http.NewServeMux()
	sub, _ := fs.Sub(static, "static")
	mux.Handle("GET /", http.FileServer(http.FS(sub)))

	mux.HandleFunc("GET /api/state", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, s.Snapshot())
	})
	mux.HandleFunc("GET /api/events", events(s))
	mux.HandleFunc("GET /api/voice/ws", voiceWS(s))
	mux.HandleFunc("GET /files/{name}", func(w http.ResponseWriter, r *http.Request) {
		name := filepath.Base(r.PathValue("name"))
		http.ServeFile(w, r, filepath.Join(s.FilesDir(), name))
	})

	mux.HandleFunc("POST /api/file", func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 22*1024*1024)
		var b struct {
			Name string `json:"name"`
			Data string `json:"data"`
		}
		if !decode(w, r, &b) {
			return
		}
		data, err := base64.StdEncoding.DecodeString(b.Data)
		if err != nil {
			fail(w, http.StatusBadRequest, "файл повреждён")
			return
		}
		if err := s.SendFile(b.Name, data); err != nil {
			fail(w, http.StatusConflict, err.Error())
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/voice/join", func(w http.ResponseWriter, r *http.Request) {
		if !s.VoiceJoin() {
			fail(w, http.StatusConflict, "Нет подключения к собеседнику")
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/voice/leave", func(w http.ResponseWriter, r *http.Request) {
		s.VoiceLeave()
		ok(w)
	})
	mux.HandleFunc("POST /api/voice/decline", func(w http.ResponseWriter, r *http.Request) {
		s.VoiceDecline()
		ok(w)
	})

	mux.HandleFunc("POST /api/host", func(w http.ResponseWriter, r *http.Request) {
		if err := s.Host(); err != nil {
			fail(w, http.StatusConflict, fmt.Sprintf("Не удалось открыть порт: %v", err))
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/connect", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Host string `json:"host"`
		}
		if !decode(w, r, &b) {
			return
		}
		if b.Host == "" {
			fail(w, http.StatusBadRequest, "Введите IP собеседника")
			return
		}
		s.Connect(b.Host)
		ok(w)
	})
	mux.HandleFunc("POST /api/bluetooth", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			MAC     string `json:"mac"`
			Channel int    `json:"channel"`
		}
		if !decode(w, r, &b) {
			return
		}
		s.ConnectBluetooth(b.MAC, b.Channel)
		ok(w)
	})
	mux.HandleFunc("POST /api/close", func(w http.ResponseWriter, r *http.Request) {
		s.Close()
		ok(w)
	})
	mux.HandleFunc("POST /api/send", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Text string `json:"text"`
		}
		if !decode(w, r, &b) {
			return
		}
		if !s.Send(b.Text) {
			fail(w, http.StatusConflict, "Нет подключения к собеседнику")
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/edit", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			MID  string `json:"mid"`
			Text string `json:"text"`
		}
		if !decode(w, r, &b) {
			return
		}
		if !s.Edit(b.MID, b.Text) {
			fail(w, http.StatusConflict, "Правка не отправлена: нет соединения")
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/delete", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			MID string `json:"mid"`
		}
		if !decode(w, r, &b) {
			return
		}
		s.Delete(b.MID)
		ok(w)
	})
	mux.HandleFunc("POST /api/read", func(w http.ResponseWriter, r *http.Request) {
		// отметка прочтения уже делается сессией, эндпоинт оставлен для совместимости интерфейса
		ok(w)
	})
	mux.HandleFunc("POST /api/typing", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			On bool `json:"on"`
		}
		if !decode(w, r, &b) {
			return
		}
		s.Typing(b.On)
		ok(w)
	})
	mux.HandleFunc("POST /api/nick", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Nick string `json:"nick"`
		}
		if !decode(w, r, &b) {
			return
		}
		if err := s.SetNick(b.Nick); err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/passphrase", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			Passphrase string `json:"passphrase"`
		}
		if !decode(w, r, &b) {
			return
		}
		if err := s.SetPassphrase(b.Passphrase); err != nil {
			fail(w, http.StatusBadRequest, err.Error())
			return
		}
		ok(w)
	})
	mux.HandleFunc("POST /api/onboarded", func(w http.ResponseWriter, r *http.Request) {
		var b struct {
			On bool `json:"on"`
		}
		if !decode(w, r, &b) {
			return
		}
		s.SetOnboarded(b.On)
		ok(w)
	})
	return mux
}

// events — поток Server-Sent Events: каждое изменение состояния уходит в браузер.
func events(s *session.Session) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		fl, isFlusher := w.(http.Flusher)
		if !isFlusher {
			http.Error(w, "потоковая передача не поддерживается", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "text/event-stream")
		w.Header().Set("Cache-Control", "no-cache")
		w.Header().Set("Connection", "keep-alive")
		ch, unsub := s.Subscribe()
		defer unsub()
		for {
			select {
			case <-r.Context().Done():
				return
			case data := <-ch:
				fmt.Fprintf(w, "data: %s\n\n", data)
				fl.Flush()
			}
		}
	}
}

func decode(w http.ResponseWriter, r *http.Request, v any) bool {
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		fail(w, http.StatusBadRequest, "неверный запрос")
		return false
	}
	return true
}

func ok(w http.ResponseWriter) {
	writeJSON(w, map[string]bool{"ok": true})
}

func fail(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}
