// OffiChat — интерфейс в браузере. Состояние приходит с сервера через SSE,
// голос идёт по WebSocket (16 кГц, 16 бит, кадры по 20 мс).
(() => {
  const $ = (id) => document.getElementById(id);
  const NICK_RE = /^[A-Za-z0-9_]{3,24}$/;
  const MAC_RE = /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/;
  const MAX_FILE = 15 * 1024 * 1024;
  const RATE = 16000, FRAME = 320;   // 20 мс

  let snap = null;
  let seen = new Set();
  let firstRender = true;
  let obStep = 1;
  let lastTypingSent = 0, lastTypingOn = false;

  // ---------- звуки ----------
  const audioFiles = {
    send: new Audio("/sounds/send.wav"),
    receive: new Audio("/sounds/receive.wav"),
    voice_on: new Audio("/sounds/voice_on.wav"),
    voice_off: new Audio("/sounds/voice_off.wav"),
  };
  const ring = new Audio("/sounds/ring.wav");
  ring.loop = true;
  let soundsOn = localStorage.getItem("sounds") !== "off";

  function play(name) {
    if (!soundsOn) return;
    try {
      const a = audioFiles[name].cloneNode();
      a.volume = 0.8;
      a.play().catch(() => {});
    } catch (_) {}
  }

  // ---------- сеть ----------
  async function api(path, body) {
    const r = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body === undefined ? {} : body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "ошибка");
    return j;
  }
  async function run(fn) {
    try { await fn(); } catch (e) { toast(e.message); }
  }

  function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.remove("hidden");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => t.classList.add("hidden"), 2800);
  }

  // ---------- онбординг ----------
  function showScreen(name) {
    $("onboarding").classList.toggle("hidden", name !== "onboarding");
    $("main").classList.toggle("hidden", name !== "main");
  }

  $("ob-next").onclick = () => run(async () => {
    if (obStep === 1) {
      const nick = $("ob-nick").value.trim();
      if (!NICK_RE.test(nick)) {
        $("ob-error").textContent = "Никнейм: 3–24 символа, латиница, цифры или _.";
        return;
      }
      const pass = $("ob-pass").value;
      if (pass.length < 6) {
        $("ob-error").textContent = "Код шифрования: минимум 6 символов. Он нужен одинаковый на всех устройствах.";
        return;
      }
      $("ob-error").textContent = "";
      await api("/api/nick", { nick });
      await api("/api/passphrase", { passphrase: pass });
      obStep = 2;
      $("ob-nick").classList.add("hidden");
      $("ob-ip").classList.remove("hidden");
      $("ob-ip").value = snap.lastIp || "";
      $("ob-hint").textContent = "Шаг 2 из 2. Введите IP собеседника и нажмите «Готово», или оставьте поле пустым и ждите подключения.";
      $("ob-next").textContent = "Готово";
      $("ob-skip").textContent = "Назад";
      return;
    }
    const ip = $("ob-ip").value.trim();
    if (ip) await api("/api/connect", { host: ip });
    else await api("/api/host");
    await api("/api/onboarded", { on: true });
  });
  $("ob-skip").onclick = () => {
    if (obStep === 2) {
      obStep = 1;
      $("ob-nick").classList.remove("hidden");
      $("ob-ip").classList.add("hidden");
      $("ob-hint").textContent = "Шаг 1 из 2. Как вас будут видеть собеседники?";
      $("ob-next").textContent = "Далее";
      $("ob-skip").textContent = "Пропустить";
      return;
    }
    run(() => api("/api/onboarded", { on: true }));
  };
  $("ob-nick").addEventListener("keydown", (e) => { if (e.key === "Enter") $("ob-next").click(); });

  // ---------- панель ----------
  $("btn-connect").onclick = () => run(() => {
    const host = $("ip").value.trim();
    if (!host) return toast("Введите IP собеседника");
    return api("/api/connect", { host });
  });
  $("btn-host").onclick = () => run(() => api("/api/host"));
  $("btn-bt").onclick = () => run(() => {
    const mac = $("bt-mac").value.trim().toUpperCase();
    if (!MAC_RE.test(mac)) return toast("Введите MAC в формате AA:BB:CC:DD:EE:FF");
    return api("/api/bluetooth", { mac, channel: parseInt($("bt-ch").value, 10) || 1 });
  });
  $("btn-stop").onclick = () => run(() => api("/api/close"));
  $("btn-pass").onclick = () => {
    const pass = prompt("Новый код шифрования (минимум 6 символов). Его нужно поменять и на телефоне:");
    if (pass === null) return;
    run(async () => {
      await api("/api/passphrase", { passphrase: pass });
      toast("Код шифрования сохранён");
    });
  };
  $("btn-nick").onclick = () => {
    const nick = prompt("Никнейм: латиница, цифры или _ (3–24)", snap.nick);
    if (nick === null) return;
    run(() => api("/api/nick", { nick: nick.trim() }));
  };
  $("btn-voice").onclick = () => {
    if (snap.voiceLocal) return run(leaveVoice);
    run(joinVoice);
  };

  // ---------- сообщения ----------
  $("send-form").onsubmit = (e) => {
    e.preventDefault();
    const text = $("input").value.trim();
    if (!text) return;
    if (!snap.connected) return toast("Сначала подключитесь к собеседнику");
    $("input").value = "";
    sendTyping(false);
    run(() => api("/api/send", { text }));
  };
  function sendTyping(on) {
    const now = Date.now();
    if (on && lastTypingOn && now - lastTypingSent < 2000) return;
    if (!on && !lastTypingOn) return;
    lastTypingOn = on;
    lastTypingSent = now;
    api("/api/typing", { on }).catch(() => {});
  }
  $("input").addEventListener("input", () => sendTyping($("input").value.trim() !== ""));

  // ---------- файлы ----------
  $("btn-attach").onclick = () => {
    if (!snap.connected) return toast("Сначала подключитесь к собеседнику");
    $("file-input").click();
  };
  $("file-input").onchange = () => {
    const f = $("file-input").files[0];
    $("file-input").value = "";
    if (!f) return;
    if (f.size > MAX_FILE) return toast("Файл больше 15 МБ");
    const reader = new FileReader();
    reader.onload = () => {
      const b64 = String(reader.result).split(",")[1] || "";
      run(() => api("/api/file", { name: f.name, data: b64 }));
    };
    reader.readAsDataURL(f);
  };

  function fileBlock(m) {
    const url = "/files/" + encodeURIComponent(m.path);
    if (m.kind === "image") {
      const img = document.createElement("img");
      img.className = "file-img";
      img.src = url;
      img.alt = m.text;
      return img;
    }
    if (m.kind === "audio") {
      const au = document.createElement("audio");
      au.className = "file-audio";
      au.controls = true;
      au.src = url;
      return au;
    }
    const box = document.createElement("div");
    box.className = "file-box";
    box.innerHTML = `<span>📄</span>`;
    const a = document.createElement("a");
    a.className = "file-link";
    a.href = url;
    a.target = "_blank";
    a.textContent = m.text + (m.kind === "video" ? " (видео)" : "");
    box.appendChild(a);
    return box;
  }

  // ---------- отображение ----------
  function tickHTML(m) {
    if (m.from !== "me" || m.kind) return "";
    const map = { sent: ["✓", ""], delivered: ["✓✓", ""], read: ["✓✓", "tick-read"], fail: ["!", "tick-fail"] };
    const [t, cls] = map[m.status] || ["✓", ""];
    return ` <span class="${cls}">${t}</span>`;
  }

  function buildMessage(m, animate) {
    if (m.from === "system") {
      const row = document.createElement("div");
      row.className = "system-row" + (animate ? " appear" : "");
      const s = document.createElement("div");
      s.className = "system";
      s.textContent = m.text;
      row.appendChild(s);
      return row;
    }
    const mine = m.from === "me";
    const row = document.createElement("div");
    row.className = "msg-row" + (mine ? " mine" : "") + (animate ? " appear" : "");
    const bubble = document.createElement("div");
    bubble.className = "bubble " + (mine ? "mine" : "peer");
    if (m.kind && m.kind !== "text") {
      bubble.appendChild(fileBlock(m));
    } else {
      const body = document.createElement("div");
      body.className = "body";
      body.textContent = m.text;
      bubble.appendChild(body);
    }
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.innerHTML = (m.edited ? "изменено " : "") + m.time + tickHTML(m);
    bubble.appendChild(meta);
    bubble.oncontextmenu = (e) => { e.preventDefault(); openMenu(m, e.clientX, e.clientY); };
    row.appendChild(bubble);
    return row;
  }

  function renderMessages(messages) {
    const list = $("list");
    const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 80;
    list.innerHTML = "";
    for (const m of messages) {
      const isNew = !seen.has(m.id);
      list.appendChild(buildMessage(m, isNew && !firstRender));
      if (isNew && !firstRender) {
        if (m.from === "me") play("send");
        if (m.from === "peer") play("receive");
      }
      seen.add(m.id);
    }
    if (atBottom || firstRender) list.scrollTop = list.scrollHeight;
    firstRender = false;
  }

  function statusLine(s) {
    if (s.connected && s.typing) return "печатает…";
    if (s.state === "waiting") return `Ждём собеседника на порту ${s.port}. IP: ${s.localIps}`;
    if (s.state === "connecting") return s.reason;
    if (s.state === "connected") return "Подключено";
    return s.reason || "Нет подключения";
  }

  function render(s) {
    const old = snap;
    snap = s;
    if (!s.onboarded) {
      showScreen("onboarding");
      return;
    }
    if ($("main").classList.contains("hidden")) showScreen("main");

    $("nick-label").textContent = "Вы: " + s.nick;
    $("peer-title").textContent = s.connected ? (s.peerNick || "Собеседник") : "Собеседник не подключён";
    $("peer-sub").textContent = statusLine(s);
    $("local-ips").textContent = "Ваш IP: " + s.localIps;
    $("btn-stop").disabled = !(s.connected || s.state === "waiting");
    $("btn-bt").disabled = !s.btSupported;
    $("btn-voice").disabled = !s.connected;
    $("btn-voice").textContent = s.voiceLocal ? "Выйти из голосового чата" : "Войти в голосовой чат";
    $("btn-voice").className = s.voiceLocal ? "" : "flat";
    $("voice-info").textContent = s.voiceLocal
      ? (s.voicePeer ? "🎙 Вы в голосе, собеседник тоже" : "🎙 Вы в голосе, ждём собеседника")
      : "";
    $("bt-info").textContent = s.btSupported
      ? "Канал узнаётся командой sdptool browse MAC."
      : "Bluetooth в ПК-версии работает только в Linux.";

    renderMessages(s.messages || []);
    handleVoiceChanges(old, s);
    handleInvite(s);
  }

  // ---------- голос ----------
  let ctx = null, ws = null, mic = null, proc = null, nextAt = 0, voiceBusy = false;

  async function joinVoice() {
    if (!snap.connected) throw new Error("Сначала подключитесь к собеседнику");
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error("Браузер не даёт доступ к микрофону. Откройте адрес 127.0.0.1 или localhost.");
    }
    if (voiceBusy) return;
    voiceBusy = true;
    try {
      mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)({ sampleRate: RATE });
      if (ctx.state === "suspended") await ctx.resume();
      await api("/api/voice/join");
      openVoiceSocket();
      startCapture();
    } catch (e) {
      stopCapture();
      throw e;
    } finally {
      voiceBusy = false;
    }
  }

  async function leaveVoice() {
    stopCapture();
    closeVoiceSocket();
    await api("/api/voice/leave").catch(() => {});
  }

  function openVoiceSocket() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${proto}//${location.host}/api/voice/ws`);
    ws.binaryType = "arraybuffer";
    ws.onmessage = (e) => playFrame(e.data);
    ws.onclose = () => { ws = null; };
  }
  function closeVoiceSocket() {
    if (ws) { try { ws.close(); } catch (_) {} ws = null; }
  }

  function startCapture() {
    const src = ctx.createMediaStreamSource(mic);
    proc = ctx.createScriptProcessor(4096, 1, 1);
    const sink = ctx.createGain();
    sink.gain.value = 0;             // обработка идёт, но звук самому себе не выводится
    let acc = new Float32Array(0);
    proc.onaudioprocess = (e) => {
      if (!ws || ws.readyState !== WebSocket.OPEN || !snap.voicePeer) return;
      const input = e.inputBuffer.getChannelData(0);
      const merged = new Float32Array(acc.length + input.length);
      merged.set(acc);
      merged.set(input, acc.length);
      let off = 0;
      while (merged.length - off >= FRAME) {
        const pcm = new Int16Array(FRAME);
        for (let i = 0; i < FRAME; i++) {
          const v = Math.max(-1, Math.min(1, merged[off + i]));
          pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
        }
        ws.send(pcm.buffer);
        off += FRAME;
      }
      acc = merged.slice(off);
    };
    src.connect(proc);
    proc.connect(sink);
    sink.connect(ctx.destination);
  }

  function stopCapture() {
    if (proc) { try { proc.disconnect(); } catch (_) {} proc = null; }
    if (mic) { mic.getTracks().forEach((t) => t.stop()); mic = null; }
  }

  function playFrame(buf) {
    if (!ctx || ctx.state === "closed") return;
    const pcm = new Int16Array(buf);
    const f32 = new Float32Array(pcm.length);
    for (let i = 0; i < pcm.length; i++) f32[i] = pcm[i] / 0x8000;
    const audioBuf = ctx.createBuffer(1, f32.length, RATE);
    audioBuf.copyToChannel(f32, 0);
    const src = ctx.createBufferSource();
    src.buffer = audioBuf;
    src.connect(ctx.destination);
    const now = ctx.currentTime;
    if (nextAt < now + 0.02) nextAt = now + 0.08; // небольшой запас, чтобы не было пауз
    src.start(nextAt);
    nextAt += audioBuf.duration;
  }

  function handleVoiceChanges(old, s) {
    if (!old) return;
    if (old.voiceLocal !== s.voiceLocal) play(s.voiceLocal ? "voice_on" : "voice_off");
    if (old.voiceLocal && !s.voiceLocal) {
      stopCapture();
      closeVoiceSocket();
    }
  }

  // ---------- приглашение ----------
  function handleInvite(s) {
    const box = $("invite");
    if (s.invite && !s.voiceLocal) {
      if (box.classList.contains("hidden")) {
        box.classList.remove("hidden");
        if (soundsOn) ring.play().catch(() => {});
        if (document.hidden && "Notification" in window && Notification.permission === "granted") {
          new Notification("OffiChat", { body: "Собеседник вызывает в голосовой чат" });
        }
      }
    } else if (!box.classList.contains("hidden")) {
      hideInvite();
    }
  }
  function hideInvite() {
    $("invite").classList.add("hidden");
    ring.pause();
    ring.currentTime = 0;
  }
  $("invite-accept").onclick = () => {
    hideInvite();
    run(joinVoice);
  };
  $("invite-decline").onclick = () => {
    hideInvite();
    run(() => api("/api/voice/decline"));
  };

  // ---------- контекстное меню ----------
  function openMenu(m, x, y) {
    const menu = $("menu");
    menu.innerHTML = "";
    const add = (label, fn, cls) => {
      const d = document.createElement("div");
      d.textContent = label;
      if (cls) d.className = cls;
      d.onclick = () => { closeMenu(); fn(); };
      menu.appendChild(d);
    };
    if (!m.kind || m.kind === "text") {
      add("Копировать", () => copy(m.text));
      add("Переслать (скопировать текст)", () => { copy(m.text); toast("Текст скопирован. Вставьте его в нужный чат."); });
    } else {
      add("Открыть файл", () => window.open("/files/" + encodeURIComponent(m.path), "_blank"));
    }
    if (m.from === "me" && m.mid && (!m.kind || m.kind === "text")) {
      add("Редактировать", () => {
        const text = prompt("Текст:", m.text);
        if (text === null || !text.trim() || text.trim() === m.text) return;
        run(() => api("/api/edit", { mid: m.mid, text: text.trim() }));
      });
      add("Удалить у всех", () => {
        if (!confirm("Удалить сообщение у всех?")) return;
        run(() => api("/api/delete", { mid: m.mid }));
      }, "danger");
    }
    menu.style.left = Math.min(x, window.innerWidth - 230) + "px";
    menu.style.top = Math.min(y, window.innerHeight - 200) + "px";
    menu.classList.remove("hidden");
  }
  function closeMenu() { $("menu").classList.add("hidden"); }
  function copy(text) {
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast("Скопировано"), () => toast("Не удалось скопировать"));
  }
  document.addEventListener("click", (e) => { if (!$("menu").contains(e.target)) closeMenu(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });

  // ---------- связь с сервером ----------
  function connect() {
    const es = new EventSource("/api/events");
    es.onmessage = (e) => {
      try { render(JSON.parse(e.data)); } catch (_) {}
    };
    es.onerror = () => { /* браузер переподключится сам, состояние придёт заново */ };
  }
  connect();
})();
