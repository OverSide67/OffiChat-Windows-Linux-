package web

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"

	"offichat/internal/session"
)

const wsGUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

// voiceWS — канал голоса по WebSocket. Браузер шлёт кадры микрофона (бинарные),
// сервер шлёт кадры собеседника. Реализация на стандартной библиотеке (RFC 6455).
func voiceWS(s *session.Session) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		key := r.Header.Get("Sec-WebSocket-Key")
		if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") || key == "" {
			http.Error(w, "нужен WebSocket", http.StatusBadRequest)
			return
		}
		hj, ok := w.(http.Hijacker)
		if !ok {
			http.Error(w, "WebSocket не поддерживается", http.StatusInternalServerError)
			return
		}
		conn, rw, err := hj.Hijack()
		if err != nil {
			return
		}
		defer conn.Close()

		sum := sha1.Sum([]byte(key + wsGUID))
		accept := base64.StdEncoding.EncodeToString(sum[:])
		rw.WriteString("HTTP/1.1 101 Switching Protocols\r\n" +
			"Upgrade: websocket\r\nConnection: Upgrade\r\n" +
			"Sec-WebSocket-Accept: " + accept + "\r\n\r\n")
		if rw.Flush() != nil {
			return
		}

		frames, unsub := s.SubscribeVoice()
		defer unsub()
		done := make(chan struct{})
		go readClient(rw.Reader, conn, s, done)

		for {
			select {
			case <-done:
				return
			case pcm := <-frames:
				if writeBinary(conn, pcm) != nil {
					return
				}
			}
		}
	}
}

// readClient читает кадры браузера: бинарные — голос, ping — отвечаем pong, close — выходим.
func readClient(r *bufio.Reader, conn net.Conn, s *session.Session, done chan struct{}) {
	defer close(done)
	for {
		op, payload, err := readFrame(r)
		if err != nil {
			return
		}
		switch op {
		case 0x2: // binary
			s.SendVoiceFrame(payload)
		case 0x8: // close
			writeFrame(conn, 0x8, nil)
			return
		case 0x9: // ping
			writeFrame(conn, 0xA, payload)
		}
	}
}

// readFrame читает один кадр клиента. Браузер присылает маскированные кадры.
func readFrame(r *bufio.Reader) (byte, []byte, error) {
	b0, err := r.ReadByte()
	if err != nil {
		return 0, nil, err
	}
	b1, err := r.ReadByte()
	if err != nil {
		return 0, nil, err
	}
	fin := b0&0x80 != 0
	op := b0 & 0x0f
	if !fin {
		return 0, nil, errors.New("фрагментированные кадры не поддерживаются")
	}
	masked := b1&0x80 != 0
	n := uint64(b1 & 0x7f)
	switch n {
	case 126:
		var b [2]byte
		if _, err := io.ReadFull(r, b[:]); err != nil {
			return 0, nil, err
		}
		n = uint64(binary.BigEndian.Uint16(b[:]))
	case 127:
		var b [8]byte
		if _, err := io.ReadFull(r, b[:]); err != nil {
			return 0, nil, err
		}
		n = binary.BigEndian.Uint64(b[:])
	}
	if n > 1<<20 {
		return 0, nil, errors.New("слишком большой кадр")
	}
	var mask [4]byte
	if masked {
		if _, err := io.ReadFull(r, mask[:]); err != nil {
			return 0, nil, err
		}
	}
	payload := make([]byte, n)
	if _, err := io.ReadFull(r, payload); err != nil {
		return 0, nil, err
	}
	if masked {
		for i := range payload {
			payload[i] ^= mask[i%4]
		}
	}
	return op, payload, nil
}

// writeBinary отправляет бинарный кадр сервера (без маски).
func writeBinary(conn net.Conn, data []byte) error {
	return writeFrame(conn, 0x2, data)
}

func writeFrame(conn net.Conn, op byte, data []byte) error {
	header := []byte{0x80 | op}
	n := len(data)
	switch {
	case n < 126:
		header = append(header, byte(n))
	case n < 65536:
		header = append(header, 126, 0, 0)
		binary.BigEndian.PutUint16(header[2:], uint16(n))
	default:
		header = append(header, 127, 0, 0, 0, 0, 0, 0, 0, 0)
		binary.BigEndian.PutUint64(header[2:], uint64(n))
	}
	_, err := conn.Write(append(header, data...))
	return err
}
