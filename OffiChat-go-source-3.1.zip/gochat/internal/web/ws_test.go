package web

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"offichat/internal/chat"
	"offichat/internal/session"
)

// Клиент WebSocket по RFC 6455: маскирует свои кадры, как браузер.
func dialWS(t *testing.T, base string) (net.Conn, *bufio.Reader) {
	t.Helper()
	addr := strings.TrimPrefix(base, "http://")
	conn, err := net.Dial("tcp", addr)
	if err != nil {
		t.Fatal(err)
	}
	key := make([]byte, 16)
	rand.Read(key)
	k := base64.StdEncoding.EncodeToString(key)
	fmt.Fprintf(conn, "GET /api/voice/ws HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"+
		"Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n", addr, k)
	r := bufio.NewReader(conn)
	status, _ := r.ReadString('\n')
	if !strings.Contains(status, "101") {
		t.Fatalf("рукопожатие: %q", status)
	}
	for {
		line, _ := r.ReadString('\n')
		if line == "\r\n" {
			break
		}
		if strings.HasPrefix(line, "Sec-WebSocket-Accept:") {
			want := sha1.Sum([]byte(k + wsGUID))
			if strings.TrimSpace(strings.TrimPrefix(line, "Sec-WebSocket-Accept:")) != base64.StdEncoding.EncodeToString(want[:]) {
				t.Fatal("неверный Sec-WebSocket-Accept")
			}
		}
	}
	return conn, r
}

func sendMaskedBinary(conn net.Conn, data []byte) {
	mask := []byte{1, 2, 3, 4}
	masked := make([]byte, len(data))
	for i := range data {
		masked[i] = data[i] ^ mask[i%4]
	}
	header := []byte{0x82}
	switch n := len(data); {
	case n < 126:
		header = append(header, 0x80|byte(n))
	case n < 65536:
		header = append(header, 0x80|126, 0, 0)
		binary.BigEndian.PutUint16(header[2:], uint16(n))
	}
	conn.Write(append(append(header, mask...), masked...))
}

func readServerBinary(r *bufio.Reader) ([]byte, error) {
	b0, err := r.ReadByte()
	if err != nil {
		return nil, err
	}
	if b0&0x0f != 0x2 {
		return nil, fmt.Errorf("ожидали бинарный кадр, пришёл %x", b0)
	}
	b1, _ := r.ReadByte()
	if b1&0x80 != 0 {
		return nil, fmt.Errorf("сервер не должен маскировать кадры")
	}
	n := int(b1 & 0x7f)
	switch n {
	case 126:
		var b [2]byte
		io.ReadFull(r, b[:])
		n = int(binary.BigEndian.Uint16(b[:]))
	case 127:
		var b [8]byte
		io.ReadFull(r, b[:])
		n = int(binary.BigEndian.Uint64(b[:]))
	}
	data := make([]byte, n)
	_, err = io.ReadFull(r, data)
	return data, err
}

func TestVoiceWebSocketRelaysBothWays(t *testing.T) {
	a, _ := session.NewWithPort(t.TempDir(), 5331)
	b, _ := session.NewWithPort(t.TempDir(), 5331)
	for _, x := range []*session.Session{a, b} {
		if err := x.SetPassphrase("общий код 42"); err != nil {
			t.Fatal(err)
		}
	}
	if err := a.Host(); err != nil {
		t.Fatal(err)
	}
	b.Connect("127.0.0.1")
	waitUntil(t, func() bool { return a.Snapshot().Connected && b.Snapshot().Connected })
	a.VoiceJoin()
	b.VoiceJoin()
	waitUntil(t, func() bool { return a.Snapshot().VoicePeer && b.Snapshot().VoicePeer })

	srv := httptest.NewServer(Handler(a))
	defer srv.Close()
	conn, r := dialWS(t, srv.URL)
	defer conn.Close()

	// браузер A -> собеседник B
	outFrame := bytes.Repeat([]byte{7}, chat.VoiceFrameBytes)
	sub, unsub := b.SubscribeVoice()
	defer unsub()
	sendMaskedBinary(conn, outFrame)
	select {
	case got := <-sub:
		if !bytes.Equal(got, outFrame) {
			t.Fatal("кадр к собеседнику повреждён")
		}
	case <-time.After(5 * time.Second):
		t.Fatal("кадр не дошёл до собеседника")
	}

	// собеседник B -> браузер A
	inFrame := bytes.Repeat([]byte{9}, chat.VoiceFrameBytes)
	deadline := time.Now().Add(5 * time.Second)
	var received []byte
	for received == nil && time.Now().Before(deadline) {
		// отправляем с B, пока A не начнёт получать (подписка может подняться позже)
		b.SendVoiceFrame(inFrame)
		conn.SetReadDeadline(time.Now().Add(200 * time.Millisecond))
		if data, err := readServerBinary(r); err == nil {
			received = data
		}
	}
	if !bytes.Equal(received, inFrame) {
		t.Fatalf("кадр от собеседника не пришёл в браузер (получено %d байт)", len(received))
	}
}

func waitUntil(t *testing.T, cond func() bool) {
	t.Helper()
	for end := time.Now().Add(5 * time.Second); time.Now().Before(end); time.Sleep(20 * time.Millisecond) {
		if cond() {
			return
		}
	}
	t.Fatal("условие не выполнилось за 5 секунд")
}

func TestFileUploadAndServe(t *testing.T) {
	a, _ := session.NewWithPort(t.TempDir(), 5332)
	h := Handler(a)
	body := `{"name":"фото.png","data":"` + base64.StdEncoding.EncodeToString([]byte("png")) + `"}`
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/api/file", strings.NewReader(body)))
	if rec.Code != http.StatusConflict {
		t.Fatalf("без соединения ждём 409, получили %d", rec.Code)
	}
}
