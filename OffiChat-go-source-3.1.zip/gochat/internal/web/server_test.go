package web

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"offichat/internal/session"
)

func TestStateAndIndexServed(t *testing.T) {
	s, err := session.NewWithPort(t.TempDir(), 5321)
	if err != nil {
		t.Fatal(err)
	}
	h := Handler(s)

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/api/state", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("/api/state: %d", rec.Code)
	}
	var snap map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &snap); err != nil {
		t.Fatalf("неверный JSON: %v", err)
	}
	if _, ok := snap["messages"]; !ok {
		t.Fatal("в состоянии нет messages")
	}

	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))
	if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), "OffiChat") {
		t.Fatalf("главная страница: %d", rec.Code)
	}
}

func TestSendWithoutConnectionReturnsConflict(t *testing.T) {
	s, _ := session.NewWithPort(t.TempDir(), 5322)
	h := Handler(s)
	req := httptest.NewRequest(http.MethodPost, "/api/send", strings.NewReader(`{"text":"тест"}`))
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != http.StatusConflict {
		t.Fatalf("ожидали 409, получили %d", rec.Code)
	}
}
