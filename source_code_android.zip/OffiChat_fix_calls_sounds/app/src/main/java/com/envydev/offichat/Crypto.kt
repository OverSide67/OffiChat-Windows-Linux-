package com.envydev.offichat

import android.content.Context
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Шифрование строк протокола. Совместимо с ПК-версией (internal/crypt):
 * ключ = PBKDF2-HMAC-SHA256(код, соль "offichat-v1", 100000 итераций, 256 бит),
 * строка = AES-GCM с случайным nonce, на проводе: "S|" + base64(nonce + шифртекст + тег).
 */
object Crypto {
    private const val PREFIX = "S|"
    private const val SALT = "offichat-v1"
    private const val ITERATIONS = 100000
    private const val KEY_BITS = 256
    private val rnd = SecureRandom()

    @Volatile private var key: ByteArray? = null

    fun ready(): Boolean = key != null

    /** Загрузить сохранённый код при старте. Вычисление ключа занимает секунду, поэтому в фоне. */
    fun loadFrom(ctx: Context) {
        val p = ProfileStore.passphrase(ctx)
        if (p.isNotEmpty()) Thread { setPassphrase(p) }.start()
    }

    fun setPassphrase(passphrase: String) {
        val spec = PBEKeySpec(
            passphrase.toCharArray(), SALT.toByteArray(StandardCharsets.UTF_8), ITERATIONS, KEY_BITS
        )
        key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun seal(line: String): String {
        val k = key ?: error("код шифрования не задан")
        val nonce = ByteArray(12).also { rnd.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, nonce))
        val body = cipher.doFinal(line.toByteArray(StandardCharsets.UTF_8))
        return PREFIX + Base64.encodeToString(nonce + body, Base64.NO_WRAP)
    }

    /** Расшифровка строки из сети. null — неверный код или подмена. */
    fun open(wire: String): String? {
        val k = key ?: return null
        if (!wire.startsWith(PREFIX)) return null
        return try {
            val raw = Base64.decode(wire.substring(PREFIX.length), Base64.NO_WRAP)
            if (raw.size < 12 + 16) return null
            val nonce = raw.copyOfRange(0, 12)
            val body = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, nonce))
            String(cipher.doFinal(body), StandardCharsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}
