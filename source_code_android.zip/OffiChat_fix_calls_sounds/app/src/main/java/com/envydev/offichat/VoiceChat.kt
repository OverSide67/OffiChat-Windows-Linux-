package com.envydev.offichat

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Log
import android.util.Base64
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Живой голосовой канал поверх уже открытого соединения ChatHub.
 * Аудио: PCM 16 кГц, моно, 16 бит, кадры по 20 мс, передаются строками "VA|<base64>".
 * Сигналы: "VJ|1" вход, "VJ|0" выход, "VH|1" ответ «я тоже в голосе».
 */
object VoiceChat {
    private const val TAG = "VoiceChat"
    private const val RATE = 16_000
    private const val FRAME_SAMPLES = 320            // 20 мс при 16 кГц
    private const val FRAME_BYTES = FRAME_SAMPLES * 2
    private const val MAX_QUEUE = 8                  // ~160 мс буфер, лишнее отбрасываем

    @Volatile var active = false
        private set
    @Volatile var peerActive = false
        private set
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var onInvite: (() -> Unit)? = null
    @Volatile var onInviteCancel: (() -> Unit)? = null

    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var appCtx: Context? = null
    private var prevMode = AudioManager.MODE_NORMAL
    private val queue = LinkedBlockingQueue<ByteArray>()

    @SuppressLint("MissingPermission")
    @Synchronized
    fun join(ctx: Context): Boolean {
        if (active) return true
        val minRec = AudioRecord.getMinBufferSize(
            RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minRec <= 0) {
            Log.e(TAG, "getMinBufferSize вернул $minRec: параметры записи не поддерживаются")
            return false
        }
        // Сначала пробуем источник с эхоподавлением, потом обычный микрофон:
        // на части прошивок (Samsung/LineageOS, Realme) VOICE_COMMUNICATION не запускается.
        val sources = intArrayOf(MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.MIC)
        var rec: AudioRecord? = null
        for (src in sources) {
            val candidate = try {
                AudioRecord(
                    src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minRec, FRAME_BYTES * 4)
                )
            } catch (e: Exception) {
                Log.e(TAG, "AudioRecord(source=$src) не создан: ${e.message}")
                null
            }
            if (candidate == null) continue
            if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                Log.i(TAG, "микрофон открыт, source=$src")
                rec = candidate
                break
            }
            Log.w(TAG, "source=$src не инициализирован (state=${candidate.state}), пробуем следующий")
            candidate.release()
        }
        if (rec == null) {
            Log.e(TAG, "микрофон не открылся ни с одним источником. Возможно, занят другим приложением")
            return false
        }
        val opened: AudioRecord = rec
        val minTrack = AudioTrack.getMinBufferSize(
            RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val tr = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minTrack, FRAME_BYTES * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val am = ctx.getSystemService(AudioManager::class.java)
        prevMode = am.mode
        am.mode = AudioManager.MODE_IN_COMMUNICATION

        appCtx = ctx.applicationContext
        recorder = opened
        track = tr
        queue.clear()
        active = true
        opened.startRecording()
        tr.play()
        Thread({ captureLoop(opened) }, "voice-capture").start()
        Thread({ playLoop(tr) }, "voice-play").start()
        ChatHub.sendVoiceLine("VJ|1")
        Sounds.play(Sounds.Kind.VOICE_ON)
        onChange?.invoke()
        return true
    }

    @Synchronized
    fun leave() {
        if (!active) return
        active = false
        peerActive = false
        ChatHub.sendVoiceLine("VJ|0")
        Sounds.play(Sounds.Kind.VOICE_OFF)
        // Остановка прерывает блокирующие read/write; сами ресурсы освобождают потоки.
        try { recorder?.stop() } catch (_: Exception) {}
        recorder = null
        track = null
        queue.clear()
        appCtx?.let { c ->
            try { c.getSystemService(AudioManager::class.java).mode = prevMode } catch (_: Exception) {}
        }
        appCtx = null
        onChange?.invoke()
    }

    /** Сигналы от собеседника: VJ|1, VJ|0, VH|1. */
    fun onPeerSignal(line: String) {
        when (line) {
            "VJ|1" -> {
                peerActive = true
                if (active) {
                    ChatHub.sendVoiceLine("VH|1")
                } else {
                    onInvite?.invoke()
                    if (!ChatHub.visible) ChatHub.postInviteNotification()
                }
            }
            "VH|1" -> peerActive = true
            "VJ|0" -> {
                peerActive = false
                queue.clear()
                onInviteCancel?.invoke()
                ChatHub.cancelInviteNotification()
            }
        }
        onChange?.invoke()
    }

    /** Кадр аудио от собеседника, base64 без префикса. */
    fun onFrame(b64: String) {
        if (!active || !peerActive) return
        val bytes = try {
            Base64.decode(b64, Base64.NO_WRAP)
        } catch (_: IllegalArgumentException) {
            return
        }
        if (bytes.size != FRAME_BYTES) return
        while (queue.size >= MAX_QUEUE) queue.poll()
        queue.offer(bytes)
    }

    private fun captureLoop(rec: AudioRecord) {
        val buf = ByteArray(FRAME_BYTES)
        try {
            while (active) {
                var off = 0
                while (off < FRAME_BYTES && active) {
                    val n = rec.read(buf, off, FRAME_BYTES - off)
                    if (n <= 0) break
                    off += n
                }
                if (active && off == FRAME_BYTES && peerActive) ChatHub.sendVoiceFrame(buf)
            }
        } finally {
            try { rec.release() } catch (_: Exception) {}
        }
    }

    private fun playLoop(tr: AudioTrack) {
        try {
            while (active) {
                val f = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                tr.write(f, 0, f.size)
            }
        } finally {
            try { tr.stop() } catch (_: Exception) {}
            try { tr.release() } catch (_: Exception) {}
        }
    }
}