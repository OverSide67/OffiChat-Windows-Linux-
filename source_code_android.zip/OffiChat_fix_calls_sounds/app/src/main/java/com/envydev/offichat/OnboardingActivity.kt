package com.envydev.offichat

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback

class OnboardingActivity : BaseActivity() {

    companion object {
        private val NICK_REGEX = Regex("^[A-Za-z0-9_]{3,24}$")
    }

    private val tvStep: TextView by lazy { findViewById(R.id.tvStep) }
    private val pageProfile: LinearLayout by lazy { findViewById(R.id.pageProfile) }
    private val pageContacts: LinearLayout by lazy { findViewById(R.id.pageContacts) }
    private val etDisplayName: EditText by lazy { findViewById(R.id.etDisplayName) }
    private val etNickname: EditText by lazy { findViewById(R.id.etNickname) }
    private val etPassphrase: EditText by lazy { findViewById(R.id.etPassphrase) }
    private val btnContinue: Button by lazy { findViewById(R.id.btnContinue) }
    private val btnAddContact: Button by lazy { findViewById(R.id.btnAddContact) }
    private val btnBackProfile: Button by lazy { findViewById(R.id.btnBackProfile) }
    private val btnFinish: Button by lazy { findViewById(R.id.btnFinish) }
    private val btnSkipContacts: Button by lazy { findViewById(R.id.btnSkipContacts) }

    private var step = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)
        supportActionBar?.hide()
        ChatHub.init(this)

        etDisplayName.setText(ProfileStore.userName(this))
        etNickname.setText(ProfileStore.nickname(this))
        etPassphrase.setText(ProfileStore.passphrase(this))

        btnContinue.setOnClickListener { onContinue() }
        btnBackProfile.setOnClickListener { showStep(1, back = true) }
        btnAddContact.setOnClickListener {
            startActivity(Intent(this, AddContactActivity::class.java))
        }
        btnFinish.setOnClickListener { complete() }
        btnSkipContacts.setOnClickListener { complete() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (step == 2) showStep(1, back = true) else finish()
            }
        })
    }

    private fun onContinue() {
        val name = etDisplayName.text.toString().trim()
        val nick = etNickname.text.toString().trim()
        etDisplayName.error = null
        etNickname.error = null
        val pass = etPassphrase.text.toString()
        etPassphrase.error = null
        if (pass.length < 6) {
            etPassphrase.error = "Минимум 6 символов: он нужен одинаковый на всех устройствах"
            etPassphrase.requestFocus()
            return
        }
        when {
            name.isEmpty() -> {
                etDisplayName.error = "Введите имя"
                etDisplayName.requestFocus()
            }
            !NICK_REGEX.matches(nick) -> {
                etNickname.error = "3–24 символа: латинские буквы, цифры или _"
                etNickname.requestFocus()
            }
            else -> {
                ProfileStore.setUserName(this, name)
                ProfileStore.setNickname(this, nick)
                ProfileStore.setPassphrase(this, pass)
                Thread { Crypto.setPassphrase(pass) }.start()
                showStep(2, back = false)
            }
        }
    }

    private fun showStep(target: Int, back: Boolean) {
        if (target == step) return
        step = target
        val (show, hide) = if (target == 2) pageContacts to pageProfile else pageProfile to pageContacts
        hide.visibility = View.GONE
        show.visibility = View.VISIBLE
        val anim = if (back) R.anim.page_in_left else R.anim.page_in_right
        show.startAnimation(AnimationUtils.loadAnimation(this, anim))
        tvStep.text = "ШАГ $target ИЗ 2"
    }

    private fun complete() {
        ProfileStore.setOnboarded(this, true)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
