package com.envydev.offichat

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity

/** Общий базовый класс: задаёт анимации перехода между экранами. */
open class BaseActivity : AppCompatActivity() {

    override fun startActivity(intent: Intent?) {
        super.startActivity(intent)
        overrideTransition(Activity.OVERRIDE_TRANSITION_OPEN, R.anim.window_enter, R.anim.window_exit)
    }

    override fun finish() {
        super.finish()
        overrideTransition(Activity.OVERRIDE_TRANSITION_CLOSE, R.anim.window_back_enter, R.anim.window_back_exit)
    }

    @SuppressLint("NewApi")
    private fun overrideTransition(type: Int, enter: Int, exit: Int) {
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(type, enter, exit)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(enter, exit)
        }
    }
}
