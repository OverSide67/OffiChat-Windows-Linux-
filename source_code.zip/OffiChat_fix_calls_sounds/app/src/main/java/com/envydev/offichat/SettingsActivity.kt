package com.envydev.offichat

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : BaseActivity() {

    private val etName: EditText by lazy { findViewById(R.id.etName) }
    private val tvLocalIp: TextView by lazy { findViewById(R.id.tvLocalIp) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        supportActionBar?.hide()
        ChatHub.init(this)

        etName.setText(ProfileStore.userName(this))
        tvLocalIp.text = "IP этого телефона: ${localIp()}, порт ${ChatHub.PORT}"

        val sw = findViewById<androidx.appcompat.widget.SwitchCompat>(R.id.switchSounds)
        sw.isChecked = ProfileStore.soundsEnabled(this)
        sw.setOnCheckedChangeListener { _, on ->
            ProfileStore.setSoundsEnabled(this, on)
            Sounds.enabled = on
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            saveName()
            finish()
        }
        findViewById<Button>(R.id.btnSaveName).setOnClickListener {
            saveName()
            toast("Имя сохранено")
        }
        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Очистить историю?")
                .setMessage("Вся переписка на этом телефоне будет удалена.")
                .setPositiveButton("Очистить") { _, _ ->
                    ChatHub.clearHistory()
                    toast("История очищена")
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
    }

    override fun onPause() {
        super.onPause()
        saveName()
    }

    private fun saveName() {
        ProfileStore.setUserName(this, etName.text.toString().trim())
    }
}