package com.envydev.offichat

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ContactsActivity : BaseActivity() {

    private val box: LinearLayout by lazy { findViewById(R.id.contactsBox) }
    private val tvEmpty: TextView by lazy { findViewById(R.id.tvEmpty) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacts)
        supportActionBar?.hide()
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startActivity(Intent(this, AddContactActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        box.removeAllViews()
        val list = ProfileStore.load(this)
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        val cur = ProfileStore.current(this)
        list.forEachIndexed { i, p -> box.addView(row(p, p == cur, i)) }
    }

    private fun row(p: Profile, selected: Boolean, index: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(6), dp(10))
            background = rounded(if (selected) "#312E81" else "#0F172A", 14)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(4), 0, dp(4)) }
            setOnClickListener {
                ProfileStore.setCurrent(this@ContactsActivity, p)
                finish()
            }
        }

        val hue = (p.name.sumOf { it.code } % 360).toFloat()
        val avatar = TextView(this).apply {
            text = p.name.trim().firstOrNull()?.uppercase() ?: "?"
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(Color.WHITE)
            background = oval(Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.75f)))
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) }
        }

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        info.addView(TextView(this).apply {
            text = p.name + if (selected) "  ✓" else ""
            textSize = 15f
            setTextColor(Color.WHITE)
        })
        info.addView(TextView(this).apply {
            text = p.details()
            textSize = 11f
            setTextColor(Color.parseColor("#64748B"))
        })

        val del = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.parseColor("#475569"))
            setPadding(dp(12), dp(4), dp(8), dp(4))
            setOnClickListener {
                val list = ProfileStore.load(this@ContactsActivity)
                if (index in list.indices) list.removeAt(index)
                ProfileStore.save(this@ContactsActivity, list)
                if (p == ProfileStore.current(this@ContactsActivity)) {
                    ProfileStore.setCurrent(this@ContactsActivity, null)
                }
                render()
            }
        }

        row.addView(avatar)
        row.addView(info)
        row.addView(del)
        return row
    }
}