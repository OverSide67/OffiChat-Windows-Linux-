package com.envydev.offichat

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Голосовой канал OffiChat поверх существующего соединения ChatHub.
 *
 * Формат аудио:
 * PCM 16 кГц, моно, 16 бит.
 * Размер кадра: 20 мс.
 *
 * Сетевые сообщения:
 * VJ|1 — вход в голосовой чат
 * VJ|0 — выход из голосового чата
 * VH|1 — подтверждение участия в голосовом чате
 * VA|<base64> — аудиокадр
 */
object VoiceChat {

    private const val TAG = "VoiceChat"

    private const val RATE = 16_000
    private const val FRAME_SAMPLES = 320
    private const val FRAME_BYTES = FRAME_SAMPLES * 2
    private const val MAX_QUEUE = 8

    @Volatile
    var active = false
        private set

    @Volatile
    var peerActive = false
        private set

    @Volatile
    var onChange: (() -> Unit)? = null

    @Volatile
    var onInvite: (() -> Unit)? = null

    @Volatile
    var onInviteCancel: (() -> Unit)? = null

    @Volatile
    private var recorder: AudioRecord? = null

    @Volatile
    private var track: AudioTrack? = null

    @Volatile
    private var appCtx: Context? = null

    private var prevMode = AudioManager.MODE_NORMAL

    private val queue = LinkedBlockingQueue<ByteArray>()

    /**
     * Подключение к голосовому чату.
     *
     * Возвращает true, если аудиоустройства удалось запустить.
     * При ошибке освобождает созданные ресурсы и возвращает false.
     */
    @SuppressLint("MissingPermission")
    @Synchronized
    fun join(ctx: Context): Boolean {
        if (active) return true

        var rec: AudioRecord? = null
        var tr: AudioTrack? = null
        var am: AudioManager? = null
        var oldMode = AudioManager.MODE_NORMAL

        try {
            // Проверяем разрешение на микрофон.
            if (
                ctx.checkSelfPermission(
                    android.Manifest.permission.RECORD_AUDIO
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                Log.e(TAG, "Нет разрешения RECORD_AUDIO")
                return false
            }

            am = ctx.getSystemService(
                Context.AUDIO_SERVICE
            ) as? AudioManager

            if (am == null) {
                Log.e(TAG, "AudioManager недоступен")
                return false
            }

            oldMode = am.mode

            // Проверяем размер буфера записи.
            val minRec = AudioRecord.getMinBufferSize(
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            if (minRec <= 0) {
                Log.e(TAG, "Некорректный буфер AudioRecord: $minRec")
                return false
            }

            // Создаём микрофон.
            rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minRec, FRAME_BYTES * 4)
            )

            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord не инициализирован")
                return false
            }

            // Проверяем размер буфера воспроизведения.
            val minTrack = AudioTrack.getMinBufferSize(
                RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            if (minTrack <= 0) {
                Log.e(TAG, "Некорректный буфер AudioTrack: $minTrack")
                return false
            }

            // Создаём аудиовыход.
            tr = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(
                            AudioAttributes.USAGE_VOICE_COMMUNICATION
                        )
                        .setContentType(
                            AudioAttributes.CONTENT_TYPE_SPEECH
                        )
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(RATE)
                        .setChannelMask(
                            AudioFormat.CHANNEL_OUT_MONO
                        )
                        .setEncoding(
                            AudioFormat.ENCODING_PCM_16BIT
                        )
                        .build()
                )
                .setBufferSizeInBytes(
                    maxOf(minTrack, FRAME_BYTES * 4)
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            if (tr.state != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "AudioTrack не инициализирован")
                return false
            }

            // Переключаем Android в режим голосового общения.
            am.mode = AudioManager.MODE_IN_COMMUNICATION

            // Запускаем микрофон.
            rec.startRecording()

            if (
                rec.recordingState !=
                AudioRecord.RECORDSTATE_RECORDING
            ) {
                throw IllegalStateException(
                    "AudioRecord не начал запись"
                )
            }

            // Запускаем воспроизведение.
            tr.play()

            if (tr.playState != AudioTrack.PLAYSTATE_PLAYING) {
                throw IllegalStateException(
                    "AudioTrack не начал воспроизведение"
                )
            }

            // Сохраняем ресурсы только после успешного запуска.
            appCtx = ctx.applicationContext
            prevMode = oldMode

            recorder = rec
            track = tr

            queue.clear()
            active = true

            // Сохраняем ссылки для аудиопотоков.
            val activeRecorder = rec
            val activeTrack = tr

            Thread(
                {
                    captureLoop(activeRecorder)
                },
                "voice-capture"
            ).apply {
                isDaemon = true
                start()
            }

            Thread(
                {
                    playLoop(activeTrack)
                },
                "voice-play"
            ).apply {
                isDaemon = true
                start()
            }

            // Уведомляем собеседника.
            ChatHub.sendVoiceLine("VJ|1")

            Sounds.play(Sounds.Kind.VOICE_ON)

            onChange?.invoke()

            Log.i(TAG, "Голосовой чат успешно запущен")

            return true

        } catch (e: Exception) {
            Log.e(
                TAG,
                "Ошибка запуска голосового чата",
                e
            )

            active = false
            recorder = null
            track = null
            queue.clear()

            // Освобождаем микрофон.
            try {
                rec?.let {
                    if (
                        it.recordingState ==
                        AudioRecord.RECORDSTATE_RECORDING
                    ) {
                        it.stop()
                    }
                }
            } catch (stopError: Exception) {
                Log.w(TAG, "Ошибка остановки микрофона", stopError)
            }

            try {
                rec?.release()
            } catch (releaseError: Exception) {
                Log.w(TAG, "Ошибка освобождения микрофона", releaseError)
            }

            // Освобождаем аудиовыход.
            try {
                tr?.let {
                    if (
                        it.playState ==
                        AudioTrack.PLAYSTATE_PLAYING
                    ) {
                        it.stop()
                    }
                }
            } catch (stopError: Exception) {
                Log.w(TAG, "Ошибка остановки AudioTrack", stopError)
            }

            try {
                tr?.release()
            } catch (releaseError: Exception) {
                Log.w(TAG, "Ошибка освобождения AudioTrack", releaseError)
            }

            // Восстанавливаем предыдущий аудиорежим.
            try {
                am?.mode = oldMode
            } catch (modeError: Exception) {
                Log.w(TAG, "Ошибка восстановления аудиорежима", modeError)
            }

            appCtx = null

            return false
        }
    }

    /**
     * Выход из голосового чата.
     */
    @Synchronized
    fun leave() {
        if (!active) return

        active = false
        peerActive = false

        try {
            ChatHub.sendVoiceLine("VJ|0")
        } catch (e: Exception) {
            Log.w(TAG, "Не удалось отправить сигнал выхода", e)
        }

        try {
            Sounds.play(Sounds.Kind.VOICE_OFF)
        } catch (e: Exception) {
            Log.w(TAG, "Не удалось воспроизвести звук выхода", e)
        }

        // Останавливаем запись.
        try {
            recorder?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка остановки записи", e)
        }

        // Останавливаем воспроизведение.
        try {
            track?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Ошибка остановки воспроизведения", e)
        }

        recorder = null
        track = null

        queue.clear()

        // Восстанавливаем аудиорежим.
        appCtx?.let { context ->
            try {
                val audioManager = context.getSystemService(
                    Context.AUDIO_SERVICE
                ) as? AudioManager

                audioManager?.mode = prevMode
            } catch (e: Exception) {
                Log.w(TAG, "Ошибка восстановления AudioManager", e)
            }
        }

        appCtx = null

        onChange?.invoke()

        Log.i(TAG, "Голосовой чат остановлен")
    }

    /**
     * Обработка сигналов собеседника.
     */
    fun onPeerSignal(line: String) {
        when (line) {
            "VJ|1" -> {
                peerActive = true

                if (active) {
                    try {
                        ChatHub.sendVoiceLine("VH|1")
                    } catch (e: Exception) {
                        Log.w(TAG, "Ошибка подтверждения голосового чата", e)
                    }
                } else {
                    onInvite?.invoke()

                    if (!ChatHub.visible) {
                        ChatHub.postInviteNotification()
                    }
                }
            }

            "VH|1" -> {
                peerActive = true
            }

            "VJ|0" -> {
                peerActive = false
                queue.clear()

                onInviteCancel?.invoke()

                ChatHub.cancelInviteNotification()
            }
        }

        onChange?.invoke()
    }

    /**
     * Получение аудиокадра от собеседника.
     */
    fun onFrame(b64: String) {
        if (!active || !peerActive) return

        val bytes = try {
            Base64.decode(b64, Base64.NO_WRAP)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Получен некорректный аудиокадр")
            return
        }

        if (bytes.size != FRAME_BYTES) {
            Log.w(TAG, "Неверный размер аудиокадра: ${bytes.size}")
            return
        }

        // Не допускаем бесконечного роста очереди.
        while (queue.size >= MAX_QUEUE) {
            queue.poll()
        }

        queue.offer(bytes)
    }

    /**
     * Чтение микрофона и передача голоса.
     */
    private fun captureLoop(rec: AudioRecord) {
        val buf = ByteArray(FRAME_BYTES)

        try {
            while (active) {
                var offset = 0

                while (offset < FRAME_BYTES && active) {
                    val count = rec.read(
                        buf,
                        offset,
                        FRAME_BYTES - offset
                    )

                    if (count < 0) {
                        Log.e(
                            TAG,
                            "Ошибка чтения микрофона: $count"
                        )
                        break
                    }

                    if (count == 0) break

                    offset += count
                }

                if (
                    active &&
                    offset == FRAME_BYTES &&
                    peerActive
                ) {
                    try {
                        ChatHub.sendVoiceFrame(buf)
                    } catch (e: Exception) {
                        Log.e(TAG, "Ошибка отправки аудиокадра", e)
                    }
                }
            }
        } catch (e: Exception) {
            if (active) {
                Log.e(TAG, "Ошибка потока микрофона", e)
            }
        } finally {
            try {
                rec.release()
            } catch (e: Exception) {
                Log.w(TAG, "Ошибка освобождения AudioRecord", e)
            }
        }
    }

    /**
     * Воспроизведение входящего голоса.
     */
    private fun playLoop(tr: AudioTrack) {
        try {
            while (active) {
                val frame = queue.poll(
                    200,
                    TimeUnit.MILLISECONDS
                ) ?: continue

                var offset = 0

                while (offset < frame.size && active) {
                    val count = tr.write(
                        frame,
                        offset,
                        frame.size - offset
                    )

                    if (count < 0) {
                        Log.e(
                            TAG,
                            "Ошибка воспроизведения: $count"
                        )
                        break
                    }

                    if (count == 0) break

                    offset += count
                }
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (e: Exception) {
            if (active) {
                Log.e(TAG, "Ошибка воспроизведения голоса", e)
            }
        } finally {
            try {
                if (tr.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    tr.stop()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Ошибка остановки AudioTrack", e)
            }

            try {
                tr.release()
            } catch (e: Exception) {
                Log.w(TAG, "Ошибка освобождения AudioTrack", e)
            }
        }
    }
}