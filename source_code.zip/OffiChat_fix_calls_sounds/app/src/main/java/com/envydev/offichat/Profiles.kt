package com.envydev.offichat

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

data class Profile(
    val name: String,
    val transport: String,
    val role: String,
    val addr: String
) {
    val isBt: Boolean get() = transport == "bt"
    val isHost: Boolean get() = role == "host"

    fun details(): String {
        val t = if (isBt) "Bluetooth" else "Wi-Fi"
        val r = if (isHost) "Хост" else "Клиент"
        val a = if (addr.isNotEmpty()) " · $addr" else ""
        return "$t · $r$a"
    }

    fun summary(): String = "$name · ${details()}"

    fun toJson(): JSONObject = JSONObject()
        .put("name", name)
        .put("transport", transport)
        .put("role", role)
        .put("addr", addr)

    companion object {
        fun fromJson(o: JSONObject) = Profile(
            o.getString("name"),
            o.getString("transport"),
            o.getString("role"),
            o.optString("addr")
        )
    }
}

object ProfileStore {
    private const val FILE = "offichat"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun userName(ctx: Context): String = prefs(ctx).getString("name", "") ?: ""

    fun setUserName(ctx: Context, name: String) {
        prefs(ctx).edit().putString("name", name).apply()
    }

    fun isOnboarded(ctx: Context): Boolean =
        prefs(ctx).getBoolean("onboarded", false) || load(ctx).isNotEmpty()

    fun setOnboarded(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("onboarded", v).apply()
    }

    fun nickname(ctx: Context): String = prefs(ctx).getString("nick", "") ?: ""

    fun setNickname(ctx: Context, nick: String) {
        prefs(ctx).edit().putString("nick", nick).apply()
    }

    fun soundsEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("sounds", true)

    fun setSoundsEnabled(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("sounds", on).apply()
    }

    fun load(ctx: Context): MutableList<Profile> {
        val p = prefs(ctx)
        val list = mutableListOf<Profile>()
        val json = p.getString("profiles", null)
        if (json != null) {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) list.add(Profile.fromJson(arr.getJSONObject(i)))
        } else {
            val old = p.getString("contacts", null)
            if (old != null) {
                val arr = JSONArray(old)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val t = if (o.getString("transport") == "bt") "bt" else "wifi"
                    list.add(Profile(o.getString("name"), t, "client", o.getString("addr")))
                }
                save(ctx, list)
            }
        }
        return list
    }

    fun save(ctx: Context, list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("profiles", arr.toString()).apply()
    }

    fun current(ctx: Context): Profile? {
        val s = prefs(ctx).getString("current", null) ?: return null
        return try {
            Profile.fromJson(JSONObject(s))
        } catch (_: Exception) {
            null
        }
    }

    fun setCurrent(ctx: Context, p: Profile?) {
        val e = prefs(ctx).edit()
        if (p == null) e.remove("current") else e.putString("current", p.toJson().toString())
        e.apply()
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(hex: String, radius: Int): GradientDrawable =
    GradientDrawable().apply {
        setColor(Color.parseColor(hex))
        cornerRadius = dp(radius).toFloat()
    }

fun oval(color: Int): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

fun Context.toast(msg: String) {
    Handler(Looper.getMainLooper()).post {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}