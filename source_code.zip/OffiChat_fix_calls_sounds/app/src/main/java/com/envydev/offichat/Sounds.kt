package com.envydev.offichat

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log

/** Звуки чата из res/raw: send, receive, voice_on, voice_off. */
object Sounds {
    enum class Kind { SEND, RECEIVE, VOICE_ON, VOICE_OFF }

    @Volatile var enabled = true

    private var pool: SoundPool? = null
    private val ids = HashMap<Kind, Int>()
    private const val TAG = "Sounds"

    fun init(ctx: Context) {
        enabled = ProfileStore.soundsEnabled(ctx)
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        val app = ctx.applicationContext
        p.setOnLoadCompleteListener { _, id, status ->
            if (status != 0) Log.w(TAG, "Не загрузился звук id=$id, статус=$status")
            else Log.d(TAG, "Звук загружен id=$id")
        }
        ids[Kind.SEND] = p.load(app, R.raw.send, 1)
        ids[Kind.RECEIVE] = p.load(app, R.raw.receive, 1)
        ids[Kind.VOICE_ON] = p.load(app, R.raw.voice_on, 1)
        ids[Kind.VOICE_OFF] = p.load(app, R.raw.voice_off, 1)
        pool = p
    }

    fun play(kind: Kind) {
        if (!enabled) return
        val id = ids[kind] ?: return
        val stream = pool?.play(id, 0.8f, 0.8f, 1, 0, 1f) ?: 0
        if (stream == 0) Log.w(TAG, "Звук $kind не проигран (ещё не загружен или заглушен)")
    }
}