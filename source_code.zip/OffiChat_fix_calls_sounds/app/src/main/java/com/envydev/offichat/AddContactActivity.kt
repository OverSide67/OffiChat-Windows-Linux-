package com.envydev.offichat

import android.bluetooth.BluetoothAdapter
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AddContactActivity : BaseActivity() {

    private val etName: EditText by lazy { findViewById(R.id.etName) }
    private val rgTransport: RadioGroup by lazy { findViewById(R.id.rgTransport) }
    private val rgRole: RadioGroup by lazy { findViewById(R.id.rgRole) }
    private val tvAddrLabel: TextView by lazy { findViewById(R.id.tvAddrLabel) }
    private val etAddr: EditText by lazy { findViewById(R.id.etAddr) }
    private val tvHint: TextView by lazy { findViewById(R.id.tvHint) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_contact)
        supportActionBar?.hide()

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        rgTransport.setOnCheckedChangeListener { _, _ -> updateForm() }
        rgRole.setOnCheckedChangeListener { _, _ -> updateForm() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { save() }
        updateForm()
    }

    private fun isBt() = rgTransport.checkedRadioButtonId == R.id.rbBt
    private fun isHost() = rgRole.checkedRadioButtonId == R.id.rbHost

    private fun updateForm() {
        val host = isHost()
        val addrVisible = if (host) View.GONE else View.VISIBLE
        tvAddrLabel.visibility = addrVisible
        etAddr.visibility = addrVisible

        etAddr.hint = if (isBt()) "MAC телефона (пусто = поиск рядом)"
        else "IP хоста (пусто = 192.168.43.1)"

        tvHint.text = when {
            host && isBt() -> "Этот телефон будет ждать подключения по Bluetooth. Собеседник выбирает «Клиент»."
            host -> "Этот телефон ждёт подключения по Wi-Fi. Например, он раздаёт точку доступа, а собеседник подключён к ней."
            isBt() -> "Bluetooth-клиент: телефоны должны быть спарены в настройках Android."
            else -> "Wi-Fi-клиент: введите IP хоста. При раздаче с телефона IP обычно 192.168.43.1."
        }
    }

    private fun save() {
        val name = etName.text.toString().trim()
        if (name.isEmpty()) {
            toast("Введите название")
            return
        }
        val host = isHost()
        val bt = isBt()
        var addr = if (host) "" else etAddr.text.toString().trim()
        if (bt) addr = addr.uppercase()

        if (!host && bt && addr.isNotEmpty() && !BluetoothAdapter.checkBluetoothAddress(addr)) {
            toast("Неверный MAC. Пример: AA:BB:CC:DD:EE:FF")
            return
        }

        val p = Profile(
            name = name,
            transport = if (bt) "bt" else "wifi",
            role = if (host) "host" else "client",
            addr = addr
        )
        val list = ProfileStore.load(this)
        list.add(p)
        ProfileStore.save(this, list)
        ProfileStore.setCurrent(this, p)
        toast("Контакт «$name» сохранён и выбран")
        finish()
    }
}