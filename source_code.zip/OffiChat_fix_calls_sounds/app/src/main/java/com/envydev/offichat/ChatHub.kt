package com.envydev.offichat

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Msg(
    val id: Int,
    val from: String,
    val kind: String,
    var text: String,
    val path: String?,
    val time: String,
    val mid: String = "",
    var status: String = "",
    var edited: Boolean = false
)

interface ChatListener {
    fun onMessage(m: Msg)
    fun onState()
    fun onChanged()
    fun onTyping()
}

fun localIp(): String {
    try {
        for (ni in java.net.NetworkInterface.getNetworkInterfaces()) {
            for (a in ni.inetAddresses) {
                if (!a.isLoopbackAddress && a is java.net.Inet4Address) return a.hostAddress ?: "?"
            }
        }
    } catch (_: Exception) {
    }
    return "?"
}

fun safeName(n: String): String {
    val base = n.substringAfterLast('/').substringAfterLast('\\').trim()
    val clean = base.map { if (it == '|' || it == '\n' || it == '\r') '_' else it }.joinToString("")
    return clean.ifEmpty { "file" }
}

fun kindOf(name: String): String {
    return when (name.substringAfterLast('.', "").lowercase()) {
        "png", "jpg", "jpeg", "gif", "webp", "bmp" -> "image"
        "mp4", "webm", "mov", "mkv", "3gp" -> "video"
        "m4a", "aac", "mp3", "ogg", "wav" -> "audio"
        else -> "file"
    }
}

object ChatHub {
    const val PORT = 5000
    const val MAX_FILE = 15 * 1024 * 1024
    private val BT_UUID: UUID = UUID.fromString("8f3c1a2e-5b7d-4e9a-9c1f-2d6e4b8a7c10")
    private const val CHANNEL_ID = "chat"

    private var appCtx: Context? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val lock = Any()
    private val messages = mutableListOf<Msg>()
    private var historyKey = ""

    @Volatile var state = "idle"
        private set
    @Volatile var status = "Не подключено"
        private set
    @Volatile var peer = ""
    @Volatile var peerNick = ""
        private set
    @Volatile var transport = "wifi"
        private set
    @Volatile var listener: ChatListener? = null
    @Volatile var visible = false

    @Volatile private var running = false
    @Volatile private var writer: PrintWriter? = null
    private val netLock = Any()
    private val readSent = HashSet<String>()
    private var lastTypingSent = 0L
    @Volatile private var peerTypingUntil = 0L
    @Volatile private var closer: Closeable? = null
    @Volatile private var listenSock: Closeable? = null

    private fun ctx(): Context = appCtx!!

    fun init(c: Context) {
        if (appCtx != null) return
        appCtx = c.applicationContext
        if (Build.VERSION.SDK_INT >= 26) {
            ctx().getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Сообщения", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun snapshot(): List<Msg> = synchronized(lock) { messages.toList() }

    private fun historyFile(): File = File(ctx().filesDir, "history.json")

    private fun readHistory(): JSONObject {
        return try {
            val f = historyFile()
            if (f.exists()) JSONObject(f.readText()) else JSONObject()
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun writeHistory(root: JSONObject) {
        try {
            historyFile().writeText(root.toString())
        } catch (_: Exception) {
        }
    }

    private fun loadHistory(key: String) {
        val root = readHistory()
        val arr = root.optJSONArray(key) ?: JSONArray()
        synchronized(lock) {
            messages.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(
                    Msg(
                        id = i,
                        from = o.getString("from"),
                        kind = o.getString("kind"),
                        text = o.getString("text"),
                        path = o.optString("path").ifEmpty { null },
                        time = o.getString("time"),
                        mid = o.optString("mid"),
                        status = o.optString("status"),
                        edited = o.optBoolean("edited", false)
                    )
                )
            }
        }
    }

    private fun saveAll() {
        val key = historyKey
        if (key.isEmpty()) return
        val arr = JSONArray()
        synchronized(lock) {
            messages.forEach { m ->
                arr.put(
                    JSONObject()
                        .put("from", m.from)
                        .put("kind", m.kind)
                        .put("text", m.text)
                        .put("path", m.path ?: "")
                        .put("time", m.time)
                        .put("mid", m.mid)
                        .put("status", m.status)
                        .put("edited", m.edited)
                )
            }
        }
        val root = readHistory()
        root.put(key, arr)
        writeHistory(root)
    }

    fun clearHistory() {
        synchronized(lock) { messages.clear() }
        historyFile().delete()
        listener?.onState()
    }

    private fun begin(bt: Boolean, text: String, st: String, key: String) {
        stop()
        transport = if (bt) "bt" else "wifi"
        historyKey = key
        loadHistory(key)
        running = true
        ChatService.start(ctx(), bt)
        setState(st, text, "")
    }

    fun stop() {
        val was = running
        running = false
        VoiceChat.leave()
        try { listenSock?.close() } catch (_: Exception) {}
        try { closer?.close() } catch (_: Exception) {}
        listenSock = null
        closer = null
        writer = null
        if (was) {
            ChatService.stop(ctx())
            setState("idle", "Отключено", "")
            add("system", "system", "Отключено")
        }
    }

    fun startWifiHost() {
        begin(false, "Ждём подключения на ${localIp()}:$PORT", "waiting", "wifi-host")
        scope.launch {
            try {
                val server = ServerSocket(PORT)
                listenSock = server
                val c = server.accept()
                server.close()
                listenSock = null
                connected(c.getInputStream(), c.getOutputStream(), c, c.inetAddress.hostAddress ?: "собеседник")
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    fun startWifiClient(host: String) {
        begin(false, "Подключаемся к $host...", "connecting", host)
        scope.launch {
            try {
                val s = Socket(host, PORT)
                closer = s
                connected(s.getInputStream(), s.getOutputStream(), s, host)
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun startBtHost(adapter: BluetoothAdapter) {
        begin(true, "Bluetooth: ждём подключения...", "waiting", "bt-host")
        scope.launch {
            try {
                val server = adapter.listenUsingRfcommWithServiceRecord("OffiChat", BT_UUID)
                listenSock = server
                val s = server.accept()
                server.close()
                listenSock = null
                val dev = s.remoteDevice
                historyKey = dev.address
                loadHistory(dev.address)
                connected(s.inputStream, s.outputStream, s, dev.name ?: dev.address)
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun connectBt(adapter: BluetoothAdapter, device: BluetoothDevice) {
        val name = device.name ?: device.address
        begin(true, "Подключаемся к $name...", "connecting", device.address)
        scope.launch {
            try {
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(BT_UUID)
                closer = s
                s.connect()
                connected(s.inputStream, s.outputStream, s, name)
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    private fun connected(input: InputStream, output: OutputStream, c: Closeable, peerName: String) {
        if (!running) {
            c.close()
            return
        }
        closer = c
        writer = PrintWriter(OutputStreamWriter(output, Charsets.UTF_8), true)
        setState("connected", "Подключено", peerName)
        add("system", "system", "Подключено")
        sendRaw("HI|${helloNick()}")

        var reason = "Соединение разорвано"
        try {
            val reader = BufferedReader(InputStreamReader(input, Charsets.UTF_8))
            while (true) {
                val line = reader.readLine() ?: break
                when {
                    line.startsWith("F|") -> receiveFile(line)
                    line.startsWith("HI|") -> receiveHello(line.substring(3))
                    line.startsWith("VA|") -> VoiceChat.onFrame(line.substring(3))
                    line == "VJ|1" || line == "VJ|0" || line == "VH|1" -> VoiceChat.onPeerSignal(line)
                    line.startsWith("M|") -> receiveText(line)
                    line.startsWith("E|") -> receiveEdit(line)
                    line.startsWith("Q|") -> receiveDelete(line)
                    line.startsWith("D|") -> updateStatus(line.substring(2), "delivered")
                    line.startsWith("X|") -> updateStatus(line.substring(2), "read")
                    line == "P|1" -> receiveTyping(true)
                    line == "P|0" -> receiveTyping(false)
                    else -> add("peer", "text", line)
                }
            }
        } catch (e: Exception) {
            reason = "Обрыв связи: ${e.message}"
        }

        VoiceChat.leave()
        peerNick = ""
        writer = null
        closer = null
        if (running) {
            running = false
            setState("idle", reason, "")
            add("system", "system", reason)
            ChatService.stop(ctx())
        }
    }

    private fun fail(e: Exception) {
        if (!running) return
        running = false
        listenSock = null
        closer = null
        writer = null
        setState("idle", "Ошибка: ${e.message}", "")
        add("system", "system", "Ошибка: ${e.message}")
        ChatService.stop(ctx())
    }

    fun sendVoiceLine(line: String) {
        val w = writer ?: return
        synchronized(netLock) {
            w.print(line + "\n")
            w.flush()
        }
    }

    fun sendVoiceFrame(pcm: ByteArray) {
        val w = writer ?: return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        synchronized(netLock) {
            w.print("VA|" + b64 + "\n")
            w.flush()
        }
    }

    fun sendText(text: String) {
        scope.launch {
            if (writer == null) {
                add("system", "system", "Нет подключения")
                return@launch
            }
            val mid = newMid()
            add("me", "text", text, null, mid, "sent")
            if (!sendRaw("M|$mid|${b64(text)}")) updateStatus(mid, "fail")
        }
    }

    /** Редактирование своего сообщения. */
    fun editMessage(mid: String, text: String) {
        val ok = synchronized(lock) {
            val m = messages.firstOrNull { it.mid == mid && it.from == "me" }
            if (m != null) {
                m.text = text
                m.edited = true
            }
            m != null
        }
        if (!ok) return
        saveAll()
        listener?.onChanged()
        scope.launch { sendRaw("E|$mid|${b64(text)}") }
    }

    /** Удаление своего сообщения у обеих сторон. */
    fun deleteMessage(mid: String) {
        val ok = synchronized(lock) { messages.removeAll { it.mid == mid && it.from == "me" } }
        if (!ok) return
        saveAll()
        listener?.onChanged()
        scope.launch { sendRaw("Q|$mid") }
    }

    /** Индикатор «печатает…». Отправляется не чаще раза в 2,5 секунды. */
    fun notifyTyping(on: Boolean) {
        val now = System.currentTimeMillis()
        if (on) {
            if (now - lastTypingSent < 2500) return
            lastTypingSent = now
            scope.launch { sendRaw("P|1") }
        } else {
            if (lastTypingSent == 0L) return
            lastTypingSent = 0L
            scope.launch { sendRaw("P|0") }
        }
    }

    fun isPeerTyping(): Boolean = System.currentTimeMillis() < peerTypingUntil

    /** Отмечает входящие сообщения прочитанными, когда пользователь открыл чат. */
    fun markAllRead() {
        scope.launch {
            val mids = synchronized(lock) {
                messages.filter { it.from == "peer" && it.mid.isNotEmpty() }.map { it.mid }
            }
            for (mid in mids) {
                if (readSent.contains(mid)) continue
                if (sendRaw("X|$mid")) readSent.add(mid)
            }
        }
    }

    private fun newMid(): String = UUID.randomUUID().toString().take(8)

    private fun b64(s: String): String =
        Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

    private fun decodeB64(s: String): String? = try {
        String(Base64.decode(s, Base64.NO_WRAP), Charsets.UTF_8)
    } catch (_: IllegalArgumentException) {
        null
    }

    private fun sendRaw(line: String): Boolean {
        val w = writer ?: return false
        synchronized(netLock) {
            w.print(line + "\n")
            w.flush()
            return !w.checkError()
        }
    }

    private fun rank(s: String): Int = when (s) {
        "sent" -> 1
        "delivered" -> 2
        "read" -> 3
        else -> 0
    }

    private fun updateStatus(mid: String, st: String) {
        val changed = synchronized(lock) {
            val m = messages.firstOrNull { it.mid == mid && it.from == "me" }
            if (m == null) false
            else if (st == "fail" || rank(st) > rank(m.status)) {
                m.status = st
                true
            } else false
        }
        if (changed) {
            saveAll()
            listener?.onChanged()
        }
    }

    private fun receiveText(line: String) {
        val parts = line.split("|", limit = 3)
        if (parts.size < 3) return
        val text = decodeB64(parts[2]) ?: return
        val mid = parts[1]
        add("peer", "text", text, null, mid, "")
        scope.launch {
            sendRaw("D|$mid")
            if (visible && sendRaw("X|$mid")) readSent.add(mid)
        }
    }

    private fun receiveEdit(line: String) {
        val parts = line.split("|", limit = 3)
        if (parts.size < 3) return
        val text = decodeB64(parts[2]) ?: return
        val ok = synchronized(lock) {
            val m = messages.firstOrNull { it.mid == parts[1] && it.from == "peer" }
            if (m != null) {
                m.text = text
                m.edited = true
            }
            m != null
        }
        if (ok) {
            saveAll()
            listener?.onChanged()
        }
    }

    private fun receiveDelete(line: String) {
        val mid = line.substring(2)
        val ok = synchronized(lock) { messages.removeAll { it.mid == mid && it.from == "peer" } }
        if (ok) {
            saveAll()
            listener?.onChanged()
        }
    }

    private fun helloNick(): String {
        val n = ProfileStore.nickname(ctx()).ifEmpty { ProfileStore.userName(ctx()) }.ifEmpty { "Собеседник" }
        return n.replace("|", "_").replace("\n", "_").take(24)
    }

    private fun receiveHello(nick: String) {
        peerNick = nick.replace("|", "_").trim().take(24)
        listener?.onState()
    }

    private fun receiveTyping(on: Boolean) {
        peerTypingUntil = if (on) System.currentTimeMillis() + 4000 else 0L
        listener?.onTyping()
    }

    fun sendFile(name: String, bytes: ByteArray) {
        scope.launch {
            val w = writer
            if (w == null) {
                add("system", "system", "Нет подключения")
                return@launch
            }
            val safe = safeName(name)
            synchronized(netLock) {
                w.print("F|$safe|${Base64.encodeToString(bytes, Base64.NO_WRAP)}\n")
                w.flush()
            }
            if (w.checkError()) {
                add("system", "system", "Файл не отправлен: связь потеряна")
            } else {
                val local = saveFile("sent_$safe", bytes)
                add("me", kindOf(safe), safe, local.absolutePath)
            }
        }
    }

    private fun receiveFile(line: String) {
        val parts = line.split("|", limit = 3)
        if (parts.size < 3) return
        try {
            val name = safeName(parts[1])
            val bytes = Base64.decode(parts[2], Base64.NO_WRAP)
            val file = saveFile(name, bytes)
            add("peer", kindOf(name), name, file.absolutePath)
        } catch (e: Exception) {
            add("system", "system", "Файл не удалось принять: ${e.message}")
        }
    }

    private fun saveFile(name: String, bytes: ByteArray): File {
        val dir = File(ctx().filesDir, "received").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(dir, "${stamp}_$name").also { it.writeBytes(bytes) }
    }

    private fun setState(s: String, text: String, peerName: String) {
        state = s
        status = text
        peer = peerName
        listener?.onState()
    }

    private fun add(
        from: String, kind: String, text: String, path: String? = null,
        mid: String = "", st: String = ""
    ) {
        val m = synchronized(lock) {
            val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            Msg(messages.size, from, kind, text, path, t, mid, st).also { messages.add(it) }
        }
        saveAll()
        when (from) {
            "me" -> Sounds.play(Sounds.Kind.SEND)
            "peer" -> Sounds.play(Sounds.Kind.RECEIVE)
        }
        listener?.onMessage(m)
        if (!visible && from != "me") {
            showNotification(if (from == "peer") peerNick.ifEmpty { peer }.ifEmpty { "Собеседник" } else "OffiChat", text)
        }
    }

    @SuppressLint("MissingPermission")
    private fun showNotification(title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(
                ctx(), 0, Intent(ctx(), MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(ctx(), CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            NotificationManagerCompat.from(ctx()).notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (_: SecurityException) {
        }
    }

    private const val CALL_CHANNEL_ID = "calls_v1"
    private const val CALL_NOTIF_ID = 4242

    /** Уведомление о входящем голосовом вызове, со звуком ring.wav. Работает и при свёрнутом приложении. */
    @SuppressLint("MissingPermission")
    fun postInviteNotification() {
        try {
            val c = ctx()
            if (Build.VERSION.SDK_INT >= 26) {
                val ch = NotificationChannel(CALL_CHANNEL_ID, "Голосовые вызовы", NotificationManager.IMPORTANCE_HIGH)
                ch.setSound(
                    Uri.parse("android.resource://${c.packageName}/${R.raw.ring}"),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                ch.enableVibration(true)
                c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
            }
            val pi = PendingIntent.getActivity(
                c, 1, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(c, CALL_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_phone_call)
                .setContentTitle("Голосовой чат")
                .setContentText("Собеседник вызывает в голосовой чат")
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            NotificationManagerCompat.from(c).notify(CALL_NOTIF_ID, n)
        } catch (e: SecurityException) {
            Log.w("Invite", "Нет разрешения на уведомления", e)
        }
    }

    fun cancelInviteNotification() {
        try {
            NotificationManagerCompat.from(ctx()).cancel(CALL_NOTIF_ID)
        } catch (_: Exception) {
        }
    }
}