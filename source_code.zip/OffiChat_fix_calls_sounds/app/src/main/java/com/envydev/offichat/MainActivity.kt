package com.envydev.offichat

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import java.io.File

class MainActivity : BaseActivity(), ChatListener {

    private val defaultHost = "192.168.43.1"
    private val handler = Handler(Looper.getMainLooper())
    private var nextId = 0
    private var emptyView: View? = null
    private var pending: Profile? = null
    private var scanAdapter: BluetoothAdapter? = null
    private var player: MediaPlayer? = null
    private var playingPath: String? = null
    private var inviteDialog: AlertDialog? = null
    private var ringPlayer: MediaPlayer? = null
    private val inviteTimeout = Runnable { dismissInvite() }
    private var scanReceiver: BroadcastReceiver? = null

    private val signalTick = object : Runnable {
        override fun run() {
            refreshHeader()
            handler.postDelayed(this, 2000)
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        val p = pending
        pending = null
        if (p != null && r.values.all { it }) startProfile(p)
        else toast("Нужны разрешения Bluetooth и геолокация")
    }

    private val liveMicLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) joinLive() else toast("Нужен доступ к микрофону")
    }

    private val notifLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> onFilePicked(uri) }

    private val viewDot: View by lazy { findViewById(R.id.viewDot) }
    private val tvPeer: TextView by lazy { findViewById(R.id.tvPeer) }
    private val tvStatus: TextView by lazy { findViewById(R.id.tvStatus) }
    private val tvSignal: TextView by lazy { findViewById(R.id.tvSignal) }
    private val btnContacts: Button by lazy { findViewById(R.id.btnContacts) }
    private val btnSettings: Button by lazy { findViewById(R.id.btnSettings) }
    private val tvProfile: TextView by lazy { findViewById(R.id.tvProfile) }
    private val btnConnect: Button by lazy { findViewById(R.id.btnConnect) }
    private val btnDisconnect: Button by lazy { findViewById(R.id.btnDisconnect) }
    private val chatScroll: ScrollView by lazy { findViewById(R.id.chatScroll) }
    private val chatBox: LinearLayout by lazy { findViewById(R.id.chatBox) }
    private val btnAttach: Button by lazy { findViewById(R.id.btnAttach) }
    private val etMessage: EditText by lazy { findViewById(R.id.etMessage) }
    private val btnSend: Button by lazy { findViewById(R.id.btnSend) }
    private val btnLive: Button by lazy { findViewById(R.id.btnLive) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        ChatHub.init(this)
        Sounds.init(this)

        if (!ProfileStore.isOnboarded(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        btnContacts.setOnClickListener { startActivity(Intent(this, ContactsActivity::class.java)) }
        btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        btnConnect.setOnClickListener { connectCurrent() }
        btnDisconnect.setOnClickListener { ChatHub.stop() }
        btnAttach.setOnClickListener { filePicker.launch("*/*") }
        btnSend.setOnClickListener { sendMessage() }
        etMessage.doAfterTextChanged { t -> ChatHub.notifyTyping(!t.isNullOrBlank()) }
        btnLive.setOnClickListener { toggleLive() }
        etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else {
                false
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ChatHub.visible = true
        ChatHub.listener = this
        ChatHub.markAllRead()
        VoiceChat.onInvite = { runOnUiThread { showInvite() } }
        VoiceChat.onInviteCancel = { runOnUiThread { dismissInvite() } }
        VoiceChat.onChange = { runOnUiThread { refreshHeader() } }
        renderAll()
        refreshHeader()
        handler.post(signalTick)
    }

    override fun onStop() {
        super.onStop()
        if (VoiceChat.active) VoiceChat.leave()
        stopPlayback()
        ChatHub.visible = false
        ChatHub.listener = null
        VoiceChat.onInvite = null
        VoiceChat.onInviteCancel = null
        dismissInvite()
        VoiceChat.onChange = null
        handler.removeCallbacks(signalTick)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        finishScan()
        stopPlayback()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        showProfile()
        refreshHeader()
    }

    override fun onMessage(m: Msg) {
        runOnUiThread {
            if (m.id >= nextId) {
                renderMsg(m)
                nextId = m.id + 1
                scrollDown()
            }
        }
    }

    override fun onState() {
        runOnUiThread {
            refreshHeader()
            renderAll()
        }
    }

    override fun onChanged() {
        runOnUiThread {
            renderAll()
            refreshHeader()
        }
    }

    override fun onTyping() {
        runOnUiThread { refreshHeader() }
    }

    private fun showProfile() {
        val p = ProfileStore.current(this)
        tvProfile.text = p?.summary() ?: "Контакт не выбран. Нажмите 👥"
    }

    private fun refreshHeader() {
        val s = ChatHub.state
        tvStatus.text = if (s == "connected" && ChatHub.isPeerTyping()) "печатает…" else ChatHub.status
        tvPeer.text = if (s == "connected") peerLabel() else "Нет собеседника"
        val color = when (s) {
            "connected" -> "#22C55E"
            "waiting", "connecting" -> "#FACC15"
            else -> "#475569"
        }
        viewDot.background = oval(Color.parseColor(color))
        btnConnect.isEnabled = s == "idle"
        btnDisconnect.isEnabled = s != "idle"
        btnAttach.isEnabled = s == "connected"
        btnSend.isEnabled = s == "connected"
        btnLive.isEnabled = s == "connected"
        btnLive.text = if (VoiceChat.active) "⏹ Выйти" else "🎙 В голос"
        tvSignal.text = signalText()
    }

    private fun peerLabel(): String {
        if (ChatHub.peerNick.isNotEmpty()) return ChatHub.peerNick
        val p = ChatHub.peer
        return ProfileStore.load(this)
            .firstOrNull { it.addr.isNotEmpty() && p.uppercase().startsWith(it.addr.uppercase()) }
            ?.name
            ?: p.ifEmpty { "Собеседник" }
    }

    private fun connectCurrent() {
        val p = ProfileStore.current(this)
        if (p == null) {
            toast("Сначала выберите контакт в 👥")
            return
        }
        if (ChatHub.state != "idle") {
            toast("Уже подключено или ждём. Нажмите «Отключить»")
            return
        }
        if (p.isBt) {
            val missing = missingBtPerms()
            if (missing.isNotEmpty()) {
                pending = p
                permLauncher.launch(missing)
                return
            }
        }
        startProfile(p)
    }

    private fun startProfile(p: Profile) {
        if (!p.isBt) {
            if (p.isHost) {
                ChatHub.startWifiHost()
            } else {
                ChatHub.startWifiClient(p.addr.ifEmpty { defaultHost })
            }
            return
        }
        val adapter = btAdapter() ?: return
        if (p.isHost) {
            ChatHub.startBtHost(adapter)
            return
        }
        if (p.addr.isNotEmpty()) {
            if (!BluetoothAdapter.checkBluetoothAddress(p.addr)) {
                toast("Неверный MAC в контакте")
                return
            }
            ChatHub.connectBt(adapter, adapter.getRemoteDevice(p.addr))
        } else {
            scanAndPick(adapter)
        }
    }

    private fun btAdapter(): BluetoothAdapter? {
        val a = getSystemService(BluetoothManager::class.java)?.adapter
        return when {
            a == null -> { toast("Bluetooth не поддерживается"); null }
            !a.isEnabled -> { toast("Включите Bluetooth"); null }
            else -> a
        }
    }

    @SuppressLint("MissingPermission")
    private fun scanAndPick(adapter: BluetoothAdapter) {
        finishScan()
        val found = mutableListOf<BluetoothDevice>()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action != BluetoothDevice.ACTION_FOUND) return
                val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                if (dev != null && found.none { it.address == dev.address }) found.add(dev)
            }
        }
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(BluetoothDevice.ACTION_FOUND),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        scanAdapter = adapter
        scanReceiver = receiver
        adapter.cancelDiscovery()
        adapter.startDiscovery()
        toast("Ищем устройства рядом (12 сек)...")

        handler.postDelayed({
            if (isDestroyed || isFinishing) return@postDelayed
            finishScan()
            val bonded = try {
                (adapter.bondedDevices ?: emptySet()).toList()
            } catch (_: SecurityException) {
                emptyList()
            }
            val all = (bonded + found).distinctBy { it.address }
            if (all.isEmpty()) {
                toast("Устройств не найдено")
            } else {
                val names = all.map { "${it.name ?: "Без имени"} (${it.address})" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Выберите устройство")
                    .setItems(names) { _, i -> ChatHub.connectBt(adapter, all[i]) }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
        }, 12_000)
    }

    @SuppressLint("MissingPermission")
    private fun finishScan() {
        scanAdapter?.let { try { it.cancelDiscovery() } catch (_: SecurityException) {} }
        scanReceiver?.let { try { unregisterReceiver(it) } catch (_: IllegalArgumentException) {} }
        scanAdapter = null
        scanReceiver = null
    }

    private fun missingBtPerms(): Array<String> {
        val perms = if (Build.VERSION.SDK_INT >= 31) {
            listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        } else {
            listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        return perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
    }

    private fun signalText(): String {
        if (VoiceChat.active) {
            return if (VoiceChat.peerActive) "🎙 в эфире" else "🎙 ждём собеседника"
        }
        if (ChatHub.state != "connected") return ""
        if (ChatHub.transport == "bt") return "Bluetooth"
        return wifiText()
    }

    @Suppress("DEPRECATION")
    private fun wifiText(): String {
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        val rssi = wm?.connectionInfo?.rssi ?: -127
        if (rssi <= -127) return "Wi-Fi: нет сети"
        val level = WifiManager.calculateSignalLevel(rssi, 4)
        val bars = "▂▄▆█".mapIndexed { i, c -> if (i <= level) c else '░' }.joinToString("")
        return "Wi-Fi $bars $rssi dBm"
    }

    private fun renderAll() {
        chatBox.removeAllViews()
        emptyView = null
        val all = ChatHub.snapshot()
        if (all.isEmpty()) {
            emptyView = TextView(this).apply {
                text = "Пока тихо.\nВыберите контакт в 👥 и нажмите «Подключить»."
                setTextColor(Color.parseColor("#475569"))
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(40), 0, 0)
            }
            chatBox.addView(emptyView)
        }
        all.forEach { renderMsg(it) }
        nextId = all.size
        scrollDown()
    }

    private fun renderMsg(m: Msg) {
        removeEmpty()
        if (m.from == "system") {
            chatBox.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(6), 0, dp(6))
                addView(TextView(this@MainActivity).apply {
                    text = m.text
                    textSize = 12f
                    setTextColor(Color.WHITE)
                    setPadding(dp(12), dp(5), dp(12), dp(5))
                    background = rounded("#8FA3B3", 14)
                })
            })
            return
        }

        val mine = m.from == "me"
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (mine) Gravity.END else Gravity.START
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        if (m.kind == "text") {
            col.addView(textBubble(m, mine))
        } else {
            col.addView(bubble(m, mine))
            col.addView(small(m.time, "#708499", 11f, dp(4)))
        }
        chatBox.addView(col)
    }

    private fun textBubble(m: Msg, mine: Boolean): View {
        val maxW = (resources.displayMetrics.widthPixels * 0.72).toInt()
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(if (mine) "#EFFDDE" else "#FFFFFF", 16)
            setPadding(dp(10), dp(6), dp(10), dp(4))
            setOnLongClickListener {
                showMsgMenu(m)
                true
            }
            addView(TextView(this@MainActivity).apply {
                text = m.text
                textSize = 15f
                setTextColor(Color.parseColor("#17212B"))
                maxWidth = maxW
            })
            addView(TextView(this@MainActivity).apply {
                gravity = Gravity.END
                textSize = 11f
                setTextColor(Color.parseColor("#708499"))
                text = metaText(m)
            })
        }
    }

    private fun metaText(m: Msg): CharSequence {
        val prefix = (if (m.edited) "изменено " else "") + m.time
        if (m.from != "me") return prefix
        val ticks = when (m.status) {
            "read", "delivered" -> "✓✓"
            "fail" -> "!"
            else -> "✓"
        }
        val full = "$prefix $ticks"
        val color = when (m.status) {
            "read" -> "#3390EC"
            "fail" -> "#DC2626"
            else -> "#708499"
        }
        return SpannableString(full).apply {
            setSpan(
                ForegroundColorSpan(Color.parseColor(color)),
                prefix.length + 1, full.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    private fun showMsgMenu(m: Msg) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "Копировать" to { copyText(m.text) }
        items += "Переслать" to { forwardText(m.text) }
        if (m.from == "me" && m.kind == "text" && m.mid.isNotEmpty()) {
            items += "Редактировать" to { editDialog(m) }
            items += "Удалить у всех" to { ChatHub.deleteMessage(m.mid) }
        }
        AlertDialog.Builder(this)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .show()
    }

    private fun editDialog(m: Msg) {
        val input = EditText(this).apply {
            setText(m.text)
            setSelection(m.text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Редактировать")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty() && t != m.text) ChatHub.editMessage(m.mid, t)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun copyText(t: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("OffiChat", t))
        toast("Скопировано")
    }

    private fun forwardText(t: String) {
        val i = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, t)
        startActivity(Intent.createChooser(i, "Переслать через"))
    }

    private fun bubble(m: Msg, mine: Boolean): View {
        val color = if (mine) "#7C3AED" else "#1E293B"
        val maxW = (resources.displayMetrics.widthPixels * 0.72).toInt()
        return when (m.kind) {
            "image" -> ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(m.path?.let { decodeScaled(it, 600) })
                background = rounded(color, 18)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(dp(220), LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnClickListener { m.path?.let { openFile(it, "image/*") } }
            }
            "audio" -> TextView(this).apply {
                text = "▶ Голосовое сообщение"
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(color, 18)
                setOnClickListener { m.path?.let { togglePlayback(it) } }
            }
            "video", "file" -> TextView(this).apply {
                text = (if (m.kind == "video") "▶ " else "📄 ") + m.text
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(color, 18)
                maxWidth = maxW
                setOnClickListener {
                    m.path?.let { openFile(it, if (m.kind == "video") "video/*" else "*/*") }
                }
            }
            else -> TextView(this).apply {
                text = m.text
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(color, 18)
                maxWidth = maxW
            }
        }
    }

    private fun decodeScaled(path: String, reqW: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqW) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun openFile(path: String, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Открыть файл"))
        } catch (e: Exception) {
            toast("Не удалось открыть: ${e.message}")
        }
    }

    private fun small(text: String, color: String, size: Float, padStart: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.parseColor(color))
            setPadding(padStart, 0, dp(4), 0)
        }

    private fun removeEmpty() {
        emptyView?.let { chatBox.removeView(it) }
        emptyView = null
    }

    private fun scrollDown() {
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val text = etMessage.text.toString().trim().replace("\n", " ")
        if (text.isEmpty()) return
        etMessage.setText("")
        ChatHub.notifyTyping(false)
        ChatHub.sendText(text)
    }

    private fun onFilePicked(uri: Uri?) {
        if (uri == null) return
        if (ChatHub.state != "connected") {
            toast("Сначала подключитесь")
            return
        }
        Thread {
            try {
                val name = queryName(uri)
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                when {
                    bytes == null -> toast("Не удалось открыть файл")
                    bytes.size > ChatHub.MAX_FILE -> toast("Файл больше 15 МБ")
                    else -> ChatHub.sendFile(name, bytes)
                }
            } catch (e: Exception) {
                toast("Ошибка файла: ${e.message}")
            }
        }.start()
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return "file_${System.currentTimeMillis()}"
    }

    private fun showInvite() {
        if (VoiceChat.active || inviteDialog?.isShowing == true) return
        startRingtone()
        inviteDialog = AlertDialog.Builder(this)
            .setTitle("Голосовой чат")
            .setMessage("Собеседник вызывает в голосовой чат")
            .setPositiveButton("Принять") { _, _ ->
                stopRingtone()
                toggleLive()
            }
            .setNegativeButton("Отклонить") { _, _ -> stopRingtone() }
            .setOnDismissListener { stopRingtone() }
            .setCancelable(false)
            .show()
        handler.postDelayed(inviteTimeout, 30_000L)
    }

    private fun dismissInvite() {
        handler.removeCallbacks(inviteTimeout)
        inviteDialog?.dismiss()
        inviteDialog = null
        stopRingtone()
    }

    private fun startRingtone() {
        stopRingtone()
        try {
            ringPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                resources.openRawResourceFd(R.raw.ring).use { fd ->
                    setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                }
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.w("Invite", "Не удалось проиграть звонок", e)
        }
    }

    private fun stopRingtone() {
        ringPlayer?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        ringPlayer = null
    }

    private fun toggleLive() {
        if (VoiceChat.active) {
            VoiceChat.leave()
            refreshHeader()
            return

        }

        if (ChatHub.state != "connected") {
            toast("Сначала подключитесь")
            return
        }

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            joinLive()
        } else {
            liveMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }


    private fun joinLive() {
        if (ChatHub.state != "connected") return
        if (!VoiceChat.join(this)) toast("Не удалось открыть микрофон")
    }

    private fun togglePlayback(path: String) {
        if (playingPath == path) {
            stopPlayback()
            return
        }
        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { stopPlayback() }
                prepare()
                start()
            }
            playingPath = path
        } catch (e: Exception) {
            stopPlayback()
            toast("Не удалось воспроизвести")
        }
    }

    private fun stopPlayback() {
        player?.let {
            try { it.stop() } catch (_: IllegalStateException) {}
            it.release()
        }
        player = null
        playingPath = null
    }

    private fun myName(): String = ProfileStore.userName(this).trim().ifEmpty { "Вы" }
}